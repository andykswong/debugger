import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import hkust.comp201.hw.HotelConfig;

/**
 * Model for the hotel system
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class HotelModel {
	/**
	 * An exception thrown when there is error when checking in or out
	 */
	public static class InvalidActionException extends Exception {
		private static final long serialVersionUID = -3525870336346678343L;

		public InvalidActionException(String errMsg) {
			super(errMsg);
		}
	}
	
	/**
	 * A listener for observing changes in HotelModel
	 */
	public interface ModelChangeListener {
		/**
		 * Invoked when a room is checked in or out.
		 */
		void roomStateChanged();
	}
	
	/**
	 * ID of criteria for searching occupants
	 */
	public static final short CRITERIA_NAME = 1, CRITERIA_MEMBER_ID = 2,
			CRITERIA_TYPE = 3, CRITERIA_COMPANY = 4;

	private HotelConfig config;
	private Room[][] rooms;
	private Date currentDate = new Date();
	private SimpleDateFormat dateFormatter = new SimpleDateFormat("d-M-yyyy");
	private SimpleDateFormat altDateFormatter = new SimpleDateFormat("dd-MM-yyyy");
	private Random randomGenerator = new Random(System.currentTimeMillis());
	
	private List<ModelChangeListener> listeners = new ArrayList<ModelChangeListener>();

	/**
	 * Constructor
	 * @param config Config of the hotel
	 */
	public HotelModel(HotelConfig config) {
		this.config = config;
		rooms = new Room[config.getNumFloors()][];

		int floor, room;
		for (int i = 0; i < rooms.length; ++i) {
			rooms[i] = new Room[config.getNumRoomsInFloor(i+1)];
			
			for (int j = 0; j < rooms[i].length; ++j) {
				floor = i + 1;
				room = j + 1;
				rooms[i][j] = new Room(floor, room, config.getRoomCapacity(floor, room), config.getRoomType(floor, room), config.getRoomRate(floor, room));
			}
		}
	}
	
	/**
	 * Subscribe the given listener to changes of this model
	 */
	public void addModelChangeListener(ModelChangeListener listener) {
		if (listener != null) {
			listeners.add(listener);
		}
	}
	
	/**
	 * Remove the given listener from listening to this model
	 */	
	public void removeModelChangeListener(ModelChangeListener listener) {
		while(listeners.remove(listener));
	}
	
	/**
	 * Notify all active listener that the model has changed
	 */
	protected void notifyModelChange() {
		for (Iterator<ModelChangeListener> iter = listeners.iterator(); iter.hasNext();) {
			iter.next().roomStateChanged();
		}
	}
	
	/**
	 * Get the hotel config
	 * @return the hotel config
	 */
	public HotelConfig getConfig() {
		return config;
	}
	
	/**
	 * Get the number of floors in the hotel
	 * @return number of floors in hotel
	 */
	public int getNumFloors() {
		return rooms.length;
	}
	
	/**
	 * Get the Room object given the foor and room number
	 * @param floor floor number
	 * @param room room number
	 * @return the Room object, or null if not exist
	 */
	public Room getRoom(int floor, int room) {
		if (floor > 0 && floor <= getNumFloors() && room > 0 && room <= rooms[floor-1].length) {
			return rooms[floor-1][room-1];
		}
		return null;
	}
	
	/**
	 * Find a list of rooms of a particular type and availability
	 * @param available whether to search for available or occupied rooms
	 * @param roomType type of room to be searched
	 * @return the list of matched rooms
	 */
	public List<Room> findRoomsByAvailability(boolean available, int roomType) {
		List<Room> result = new ArrayList<Room>();
		
		for (int i = 0; i < rooms.length; ++i) {
			for (int j = 0; j < rooms[i].length; ++j) {
				if (rooms[i][j].getType() == roomType && rooms[i][j].isOccupied() != available) {
					result.add(rooms[i][j]);
				}
			}
		}

		return result;
	}
	
	/**
	 * Find a list of rooms based on availability
	 * @param available whether to search for available or occupied rooms
	 * @return the list of matched rooms
	 */
	public List<Room> findRoomsByAvailability(boolean available) {
		List<Room> result = new ArrayList<Room>();
		
		for (int i = 0; i < rooms.length; ++i) {
			for (int j = 0; j < rooms[i].length; ++j) {
				if (rooms[i][j].isOccupied() != available) {
						result.add(rooms[i][j]);
				}
			}
		}

		return result;
	}
	
	/**
	 * Find rooms by searching occupants' name, member ID, type or company
	 * @param criteria one of CRITERIA_NAME, CRITERIA_MEMBER_ID, CRITERIA_TYPE and CRITERIA_COMPANY
	 * @param query what to search
	 * @return the list of matched rooms
	 */
	public List<Room> findRoomsByOccupant(int criteria, final String query) {
		List<Room> result = new ArrayList<Room>();
		HotelUtil.Predicate<Occupant> pred;
		
		switch (criteria) {
		case CRITERIA_NAME:
			pred = new HotelUtil.Predicate<Occupant>() {
				@Override
				public boolean apply(Occupant val) {
					return val.getName().equals(query);
				}
			};
			break;
		case CRITERIA_MEMBER_ID:
			pred = new HotelUtil.Predicate<Occupant>() {
				@Override
				public boolean apply(Occupant val) {
					return val.getID().equals(query);
				}
			};
			break;
		case CRITERIA_TYPE:
			pred = new HotelUtil.Predicate<Occupant>() {
				@Override
				public boolean apply(Occupant val) {
					String type = (val.getType() == Occupant.STANDARD ? "Standard" : "Business");
					return type.equals(query);
				}
			};
			break;
		case CRITERIA_COMPANY:
			pred = new HotelUtil.Predicate<Occupant>() {
				@Override
				public boolean apply(Occupant val) {
					return val.getCompany().equals(query);
				}
			};
			break;
		default:
			return null;
		}

		for (int i = 0; i < rooms.length; ++i) {
			for (int j = 0; j < rooms[i].length; ++j) {
				if (rooms[i][j].isOccupied()) {
					if (pred.apply(rooms[i][j].getOccupant())) {
						result.add(rooms[i][j]);
					}
				}
			}
		}

		return result;
	}
	
	/**
	 * Check in a customer
	 * @param checkInDate date of check in
	 * @param occupant customer to be checked in
	 * @param netAddr ethernet address used by the room; null if not used
	 * @throws InvalidActionException thrown when cannot check in the room
	 */
	protected void checkIn(Room room, Date checkInDate, Occupant occupant, String netAddr) throws InvalidActionException {
		if (room == null) {
			throw new InvalidActionException(HotelUtil.MSG_INVALID_ROOM);			
		}
		
		synchronized (room) {
			if (room.isOccupied()) {		
				throw new InvalidActionException(HotelUtil.MSG_ROOM_OCCUPIED);
			} else if (!HotelUtil.isValidMemberID(occupant.getID())) {
				throw new InvalidActionException(HotelUtil.MSG_INVALID_FORMAT);
			}
	
			if (occupant.getType() == Occupant.BUSINESS && netAddr != null) {
				if (!HotelUtil.isValidEthernetAddress(netAddr)) {
					throw new InvalidActionException(HotelUtil.MSG_INVALID_FORMAT);
				}
				room.setDataService(netAddr);
			}
			
			room.setCheckInDate(checkInDate);
			room.setOccupant(occupant);
			
			notifyModelChange();
		}
	}
	
	/**
	 * Check in a standard customer
	 * @param room Room to check in
	 * @param checkInDate date of check in
	 * @param name name of customer
	 * @param id id of customer
	 * @throws InvalidActionException thrown when cannot check in the room
	 */
	public void checkIn(Room room, Date checkInDate, String name, String id) throws InvalidActionException {	
		Occupant occupant = new Occupant(name, id);
		checkIn(room, checkInDate, occupant, null);
	}
	
	/**
	 * Check in a business customer
	 * @param room Room to check in
	 * @param checkInDate date of check in
	 * @param name name of customer
	 * @param id id of customer
	 * @param company company of customer
	 * @param netAddr ethernet address used by the room; null if not used
	 * @throws InvalidActionException thrown when cannot check in the room
	 */
	public void checkIn(Room room, Date checkInDate, String name, String id, String company, String netAddr) throws InvalidActionException {		
		Occupant occupant = new Occupant(name, id, company);
		checkIn(room, checkInDate, occupant, netAddr);
	}
	
	/**
	 * Check out a room
	 * @param room Room to check out
	 * @param checkOutDate date of check out
	 * @throws InvalidActionException thrown if cannot check out the given room
	 */
	public void checkOut(Room room, Date checkOutDate) throws InvalidActionException {
		if (room == null) {
			throw new InvalidActionException(HotelUtil.MSG_INVALID_ROOM);			
		}
		
		synchronized (room) {
			if (!room.isOccupied()) {		
				throw new InvalidActionException(HotelUtil.MSG_ROOM_EMPTY);
			} else if (room.getCheckInDate().compareTo(checkOutDate) >= 0) {
				throw new InvalidActionException(HotelUtil.MSG_INVALID_DATE);
			}
			
			room.setOccupant(null);
			room.setDataService(null);
			room.setCheckInDate(null);
			
			notifyModelChange();
		}
	}

	/**
	 * Get the date format used by the system 
	 * @return the system date format
	 */
	public DateFormat getDateFormat() {
		return dateFormatter;
	}

	/**
	 * Get the alternative date format used by the system (mainly in GUI) 
	 * @return the alternative date format
	 */
	public DateFormat getAltDateFormat() {
		return altDateFormatter;
	}

	/**
	 * Get current date
	 * @return current date
	 */
	public Date getCurrentDate() {
		return currentDate;
	}

	/**
	 * Increment the current date
	 * @param days number of days to increment
	 */
	public void incrementDate(int days) {		
		Calendar cal = Calendar.getInstance();
	    cal.setTime(currentDate);
	    cal.add(Calendar.DATE, days);
	    currentDate = cal.getTime();
	}

	/**
	 * Get the current date string
	 * @return current date, formatted with system date format
	 */
	public String getCurrentDateString() {
		return getDateFormat().format(getCurrentDate());
	}


	/**
	 * Get a random id for customer
	 * @return the random id
	 */	
	public String getRandomID() {
		char c = (char) ('A' + Math.abs(randomGenerator.nextInt() % 26));
		long i = Math.abs(randomGenerator.nextLong() % 100000000L);
		return c + String.format("%08d", i);
	}
}
