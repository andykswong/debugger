import hkust.comp201.hw.HotelConfig;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormat;
import java.util.List;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * The list-based implementation of GUI view
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class ListView extends GUIView {
	/**
	 * Constructor
	 */
	public ListView(HotelModel model) {
		super(model);
	}
	
	@Override
	public CommandPanel getCheckInPanel() {
		return new CheckInPanel(hotelModel);
	}
	
	/**
	 * Panel for the check in interface using list
	 */
	private static class CheckInPanel extends CommandPanel {
		private static final long serialVersionUID = -7306083043044714618L;
		
		private GUICommand.CheckInCommand command;
		
		private JTextField IDField;	
		private JTextField nameField;
		private JComboBox<String> typeField;
		private JTextField companyField;
		private JTextField checkInDateField;
		private JComboBox<String> dataServiceField;
		private JTextField eternetField;
		
		private JList<Room> availableRoomList;
		
		private JPanel optionsPanel;
		
		/**
		 * Constructor
		 */
		public CheckInPanel(HotelModel model) {
			super(model);
			command = new GUICommand.CheckInCommand(model);
			setupUI();
			update();
		}
		
		/**
		 * Setup the UI for the panel
		 */
		private void setupUI() {
			setLayout(new BorderLayout());
			
			optionsPanel = new JPanel();
			optionsPanel.setLayout(new BorderLayout());
			add(optionsPanel, BorderLayout.WEST);			
			
			JButton btnCheckIn = new JButton("Check In");
			optionsPanel.add(btnCheckIn, BorderLayout.SOUTH);
			btnCheckIn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (command.getSelectedRoom() == null) {
						JOptionPane.showMessageDialog(CheckInPanel.this,
								"No room is selected", "Input Error",
								JOptionPane.INFORMATION_MESSAGE);
						return;
					}

					try {
						command.exec();
					} catch (HotelModel.InvalidActionException e) {
						JOptionPane.showMessageDialog(CheckInPanel.this, e.getMessage(),
								"Input Error", JOptionPane.INFORMATION_MESSAGE);
					}
					
					update();
				}
			});
						
			setupRoomInfoPanel();
			setupRoomList();
		}
		
		/**
		 * Setup the panel for input
		 */
		private void setupRoomInfoPanel() {
			JPanel mainPanel = new JPanel();
			optionsPanel.add(mainPanel, BorderLayout.CENTER);
			
			JPanel contentPanel = new JPanel();
			mainPanel.add(contentPanel);
			contentPanel.setBorder(new EmptyBorder(0, 5, 0, 5));
			contentPanel.setLayout(new GridLayout(11, 2, 1, 1));
					
			// Occupant Details
			
			JLabel lblOccupantDetails = new JLabel("Occupant Details:");
			contentPanel.add(lblOccupantDetails);
			
			Component rigidArea_2 = Box.createRigidArea(null);
			contentPanel.add(rigidArea_2);
			
			JLabel lblId = new JLabel("ID: ");
			contentPanel.add(lblId);
			
			IDField = new JTextField();			
			IDField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					String id = IDField.getText();
					if (HotelUtil.isValidMemberID(id)) {
						command.setID(id);
					} else if (!"".equals(id)) {
						IDField.setText(command.getID());
						JOptionPane
								.showMessageDialog(
										CheckInPanel.this,
										"The format of the inputted ID is invalid. It should be an English letter followed by exactly 8 digits",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			contentPanel.add(IDField);
			
			JLabel lblName = new JLabel("Name:");
			contentPanel.add(lblName);
			
			nameField = new JTextField();			
			nameField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					command.setName(nameField.getText());
				}
			});
			contentPanel.add(nameField);
			
			JLabel lblType = new JLabel("Type:");
			contentPanel.add(lblType);
			
			typeField = new JComboBox<String>();
			typeField.setModel(new DefaultComboBoxModel<String>(new String[] {"Standard", "Business"}));
			typeField.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					command.setType(typeField.getSelectedIndex() == 0 ? Occupant.STANDARD
							: Occupant.BUSINESS);
					updateDataService();
				}
			});
			contentPanel.add(typeField);
			
			JLabel lblCompany = new JLabel("Company:");
			contentPanel.add(lblCompany);
			
			companyField = new JTextField();
			contentPanel.add(companyField);
			companyField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					command.setCompany(companyField.getText());
				}
			});
			
			Component rigidArea1 = Box.createRigidArea(null);
			contentPanel.add(rigidArea1);
			
			Component rigidArea2 = Box.createRigidArea(null);
			contentPanel.add(rigidArea2);
			
			// Occupation details
			
			JLabel lblOccupationDetails = new JLabel("Occupation Details:");
			contentPanel.add(lblOccupationDetails);
			
			Component rigidArea3 = Box.createRigidArea(null);
			contentPanel.add(rigidArea3);
			
			JLabel lblDateOfCheckin = new JLabel("Date of Check-in (dd-MM-yyyy):");
			contentPanel.add(lblDateOfCheckin);
			
			checkInDateField = new JTextField();
			checkInDateField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					String date = checkInDateField.getText();
					DateFormat formatter = hotelModel.getAltDateFormat();
					try {
						command.setCheckInDate(formatter.parse(date));
					} catch (Exception ex) {
						checkInDateField.setText(formatter.format(command
								.getCheckInDate()));
						JOptionPane
								.showMessageDialog(
										CheckInPanel.this,
										"The format of the inputted check-in date is invalid",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			contentPanel.add(checkInDateField);
			
			JLabel lblIsDataService = new JLabel("Is Data Service Required?");
			contentPanel.add(lblIsDataService);
			
			dataServiceField = new JComboBox<String>();
			dataServiceField.setModel(new DefaultComboBoxModel<String>(new String[] {"Yes", "No"}));
			dataServiceField.setEnabled(false);
			dataServiceField.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					if (dataServiceField.getSelectedItem().equals("Yes")) {
						command.setDataRequired(true);
					} else {
						command.setDataRequired(false);
					}
					updateDataService();
				}
			});
			contentPanel.add(dataServiceField);
			
			JLabel lblEthernetAddress = new JLabel("Ethernet Address:");
			contentPanel.add(lblEthernetAddress);
			
			eternetField = new JTextField();
			eternetField.setEnabled(false);
			eternetField.addFocusListener(new FocusAdapter() {
				public void focusLost(FocusEvent e) {
					String addr = eternetField.getText();
					if (HotelUtil.isValidEthernetAddress(addr)) {
						command.setEthernetAddress(addr);
					} else {
						JOptionPane
								.showMessageDialog(
										CheckInPanel.this,
										"The format of the inputted ethernet address is invalid",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
						eternetField.setText(command.getEthernetAddress());
					}
				}
			});
			contentPanel.add(eternetField);
		}
		
		/**
		 * Setup the room list view
		 */
		private void setupRoomList() {
			JPanel mainPanel = new JPanel();
			mainPanel.setLayout(new BorderLayout());
			add(mainPanel, BorderLayout.CENTER);
			
			JLabel lblAvailableRoomList = new JLabel("Available Room List:");
			mainPanel.add(lblAvailableRoomList, BorderLayout.NORTH);
			
			availableRoomList = new JList<Room>();
			mainPanel.add(new JScrollPane(availableRoomList), BorderLayout.CENTER);

			availableRoomList.setSelectionMode(0);
			availableRoomList
					.addListSelectionListener(new ListSelectionListener() {
						@Override
						public void valueChanged(ListSelectionEvent e) {
							Room room = availableRoomList.getSelectedValue();
							if (room != null) {
								command.setSelectedRoom(room);
								updateDataService();
							}
						}
					});
		}

		@Override
		public void update() {
			List<Room> list = hotelModel.findRoomsByAvailability(true);
			availableRoomList.setListData(list.toArray(new Room[list.size()]));
			
			Room selectedRoom = command.getSelectedRoom();
			if (!list.contains(selectedRoom)) {
				command.setSelectedRoom(null);
			}
			
			if (selectedRoom != null) {
				availableRoomList.setSelectedValue(selectedRoom, true);
			}

			IDField.setText(command.getID());
			nameField.setText(command.getName());
			typeField
					.setSelectedIndex(command.getType() == Occupant.STANDARD ? 0
							: 1);
			companyField.setText(command.getCompany());
			checkInDateField.setText(hotelModel.getAltDateFormat().format(
					command.getCheckInDate()));
			updateDataService();
			eternetField.setText(command.getEthernetAddress());
		}

		/**
		 * update only the data service part of the input panel
		 */
		private void updateDataService() {
			Room room = command.getSelectedRoom();
			if (room == null || room.getType() == HotelConfig.STANDARD_ROOM
					|| command.getType() == Occupant.STANDARD) {
				dataServiceField.setEnabled(false);
				eternetField.setEnabled(false);
				if (dataServiceField.getSelectedItem().equals("Yes")) {
					dataServiceField.setSelectedItem("No");
				}
				command.setDataRequired(false);
			} else {
				dataServiceField.setEnabled(true);
				if (command.isDataRequired()) {
					if (dataServiceField.getSelectedItem().equals("No")) {
						dataServiceField.setSelectedItem("Yes");
					}
					eternetField.setEnabled(true);
				} else {
					if (dataServiceField.getSelectedItem().equals("Yes")) {
						dataServiceField.setSelectedItem("No");
					}
					eternetField.setEnabled(false);
				}
			}
		}

		@Override
		public void accept(GUICommand command) {
			this.command = (GUICommand.CheckInCommand)command;
			update();
		}		
	}

	@Override
	public CommandPanel getCheckOutPanel() {
		return new CheckOutPanel(hotelModel);
	}
	
	/**
	 * Panel for check out interface using list
	 */
	private static class CheckOutPanel extends CommandPanel {
		private static final long serialVersionUID = 1674896023128758675L;
		
		private GUICommand.CheckOutCommand command;
		
		private JTextField IDField;	
		private JTextField nameField;
		private JComboBox<String> typeField;
		private JTextField companyField;
		private JTextField checkInDateField;
		private JTextField checkOutDateField;
		private JComboBox<String> dataServiceField;
		private JTextField eternetField;

		private JPanel optionsPanel;

		private JList<Room> occupiedRoomList;
		
		/**
		 * Constructor
		 */
		public CheckOutPanel(HotelModel model) {
			super(model);
			command = new GUICommand.CheckOutCommand(model);
			setupUI();
			update();
		}
		
		/**
		 * Setup the UI for this panel
		 */
		private void setupUI() {
			setLayout(new BorderLayout());
			
			optionsPanel = new JPanel();
			optionsPanel.setLayout(new BorderLayout());
			add(optionsPanel, BorderLayout.WEST);			
			
			JButton btnCheckOut = new JButton("Check Out");
			btnCheckOut.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (command.getSelectedRoom() == null) {
						JOptionPane.showMessageDialog(CheckOutPanel.this,
								"No room is selected", "Input Error",
								JOptionPane.INFORMATION_MESSAGE);
						return;
					}
					
					try {
						command.exec();
					} catch (HotelModel.InvalidActionException e) {
						JOptionPane.showMessageDialog(CheckOutPanel.this, e.getMessage(),
								"Input Error", JOptionPane.INFORMATION_MESSAGE);
					}
					
					update();
				}
			});
			optionsPanel.add(btnCheckOut, BorderLayout.SOUTH);
						
			setupRoomInfoPanel();
			setupRoomList();
		}
				
		/**
		 * Setup the panel for input
		 */
		private void setupRoomInfoPanel() {
			JPanel mainPanel = new JPanel();
			optionsPanel.add(mainPanel, BorderLayout.CENTER);
			
			JPanel contentPanel = new JPanel();
			mainPanel.add(contentPanel);
			contentPanel.setBorder(new EmptyBorder(0, 5, 0, 5));
			contentPanel.setLayout(new GridLayout(12, 2, 1, 1));
			
			// Occupant Details
			
			JLabel lblOccupantDetails = new JLabel("Occupant Details:");
			contentPanel.add(lblOccupantDetails);
			
			Component rigidArea = Box.createRigidArea(null);
			contentPanel.add(rigidArea);
			
			JLabel lblId = new JLabel("ID: ");
			contentPanel.add(lblId);
			
			IDField = new JTextField();
			IDField.setEnabled(false);
			contentPanel.add(IDField);
			
			JLabel lblName = new JLabel("Name:");
			contentPanel.add(lblName);
			
			nameField = new JTextField();
			nameField.setEnabled(false);
			contentPanel.add(nameField);
			
			JLabel lblType = new JLabel("Type:");
			contentPanel.add(lblType);
			
			typeField = new JComboBox<String>();
			typeField.setEnabled(false);
			typeField.setModel(new DefaultComboBoxModel<String>(new String[] {"Standard", "Business"}));
			contentPanel.add(typeField);
			
			JLabel lblCompany = new JLabel("Company:");
			contentPanel.add(lblCompany);
			
			companyField = new JTextField();
			companyField.setEnabled(false);
			contentPanel.add(companyField);
			
			Component rigidArea1 = Box.createRigidArea(null);
			contentPanel.add(rigidArea1);
			
			Component rigidArea2 = Box.createRigidArea(null);
			contentPanel.add(rigidArea2);
			
			// Occupation Details
			
			JLabel lblOccupationDetails = new JLabel("Occupation Details:");
			contentPanel.add(lblOccupationDetails);
			
			Component rigidArea3 = Box.createRigidArea(null);
			contentPanel.add(rigidArea3);
			
			JLabel lblDateOfCheckin = new JLabel("Date of Check-in (dd-MM-yyyy):");
			contentPanel.add(lblDateOfCheckin);
			
			checkInDateField = new JTextField();
			checkInDateField.setEnabled(false);
			contentPanel.add(checkInDateField);
			
			JLabel lblDateOfCheckout = new JLabel("Date of Check-out (dd-MM-yyyy):");
			contentPanel.add(lblDateOfCheckout);
			
			checkOutDateField = new JTextField();
			checkOutDateField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					String date = checkOutDateField.getText();
					DateFormat formatter = hotelModel.getAltDateFormat();
					try {
						command.setCheckOutDate(formatter.parse(date));
					} catch (Exception ex) {
						checkOutDateField.setText(formatter.format(command
								.getCheckOutDate()));
						JOptionPane
								.showMessageDialog(
										CheckOutPanel.this,
										"The format of the inputted check-out date is invalid",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			contentPanel.add(checkOutDateField);
					
			JLabel lblIsDataService = new JLabel("Is Data Service Required?");
			contentPanel.add(lblIsDataService);
			
			dataServiceField = new JComboBox<String>();
			dataServiceField.setModel(new DefaultComboBoxModel<String>(new String[] {"Yes", "No"}));
			dataServiceField.setEnabled(false);
			contentPanel.add(dataServiceField);
			
			JLabel lblEthernetAddress = new JLabel("Ethernet Address:");
			contentPanel.add(lblEthernetAddress);
			
			eternetField = new JTextField();
			eternetField.setEnabled(false);
			eternetField.setText("00:00:00:00:00:00");
			contentPanel.add(eternetField);
		}
		
		/**
		 * Setup the room list
		 */
		private void setupRoomList() {
			JPanel mainPanel = new JPanel();
			add(mainPanel, BorderLayout.CENTER);
			mainPanel.setLayout(new BorderLayout(0, 0));
			
			JLabel lblOccupiedRoomList = new JLabel("Occupied Room List:");
			mainPanel.add(lblOccupiedRoomList, BorderLayout.NORTH);
			
			occupiedRoomList = new JList<Room>();
			mainPanel.add(new JScrollPane(occupiedRoomList), BorderLayout.CENTER);	
			
			occupiedRoomList.setSelectionMode(0);
		    occupiedRoomList.setSelectionBackground(Color.lightGray);
			occupiedRoomList
					.addListSelectionListener(new ListSelectionListener() {
						public void valueChanged(ListSelectionEvent e) {
							Room room = occupiedRoomList.getSelectedValue();
							if (room != null && room != command.getSelectedRoom()) {
								command.setSelectedRoom(room);
								update();
							}
						}
					});
		}

		@Override
		public void update() {
			List<Room> list = hotelModel.findRoomsByAvailability(false);
			occupiedRoomList.setListData(list.toArray(new Room[list.size()]));
			
			checkOutDateField.setText(hotelModel.getAltDateFormat().format(command.getCheckOutDate()));
			
			Room selectedRoom = command.getSelectedRoom();		
			if (!list.contains(selectedRoom)) {
				selectedRoom = null;
				command.setSelectedRoom(null);
			}
			
			if (selectedRoom != null) {
				occupiedRoomList.setSelectedValue(selectedRoom,	true);
				
				Occupant occupant = selectedRoom.getOccupant();

				IDField.setText(occupant.getID());
				nameField.setText(occupant.getName());
				typeField.setSelectedIndex(occupant.getType() == Occupant.STANDARD ? 0 : 1);
			    companyField.setText(occupant.getCompany());
			    checkInDateField.setText(hotelModel.getAltDateFormat().format(selectedRoom.getCheckInDate()));
			    if (selectedRoom.getDataService() != null) {
					dataServiceField.setSelectedItem("Yes");
			    } else {
					dataServiceField.setSelectedItem("No");
				}
			    eternetField.setText(selectedRoom.getDataService());
			}
		}

		@Override
		public void accept(GUICommand command) {
			this.command = (GUICommand.CheckOutCommand)command;
			update();
		}		
	}
	
	@Override
	public CommandPanel getSearchPanel() {			
		return new SearchPanel(hotelModel);
	}
	
	/**
	 * Panel for searching using list
	 */
	private static class SearchPanel extends CommandPanel {
		private static final long serialVersionUID = 1088778246637363980L;
		
		private GUICommand.SearchCommand command;
		
		private JPanel optionsPanel;
		private JList<Room> searchedRoomList;
		
		private JTextField searchField;
		private JComboBox<String> searchTypeField;
		
		/**
		 * Constructor
		 */
		public SearchPanel(HotelModel model) {
			super(model);
			command = new GUICommand.SearchCommand(model);
			setupUI();
			update();
		}
		
		/**
		 * Setup the UI for this panel
		 */
		private void setupUI() {
			setLayout(new BorderLayout());
			
			optionsPanel = new JPanel();
			optionsPanel.setLayout(new BorderLayout());
			add(optionsPanel, BorderLayout.WEST);			
			
			JButton btnSearch = new JButton("Search");
			btnSearch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					command.exec();
					update();
				}
			});
			optionsPanel.add(btnSearch, BorderLayout.SOUTH);
			
			setupSearchDetails();
			setupRoomList();
		}
			
		/**
		 * Setup the input panel
		 */
		private void setupSearchDetails() {
			JPanel searchDetailPanel = new JPanel();			
			optionsPanel.add(searchDetailPanel, BorderLayout.CENTER);		
			
			JPanel mainPanel = new JPanel();			
			mainPanel.setLayout(new GridLayout(3, 2, 1, 1));
			searchDetailPanel.add(mainPanel);	
			
			JLabel lblSearchDetails = new JLabel("Search Details:");
			mainPanel.add(lblSearchDetails);
			
			Component rigidArea1 = Box.createRigidArea(null);
			mainPanel.add(rigidArea1);
			
			JLabel lblSearchField = new JLabel("Search Field:");
			mainPanel.add(lblSearchField);
			
			searchField = new JTextField(15);
			searchField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					command.setQuery(searchField.getText());
				}
			});
			mainPanel.add(searchField);
			
			JLabel lblType = new JLabel("Type:");
			mainPanel.add(lblType);
			
			searchTypeField = new JComboBox<String>();
			searchTypeField.setModel(new DefaultComboBoxModel<String>(
					new String[] { "Name", "ID", "Type", "Company" }));
			searchTypeField.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					command.setCriteria((short) (searchTypeField
							.getSelectedIndex() + 1));
				}
			});
			mainPanel.add(searchTypeField);			
		}
				
		/**
		 * Setup the result list
		 */
		private void setupRoomList() {
			JPanel mainPanel = new JPanel();
			add(mainPanel, BorderLayout.CENTER);
			mainPanel.setLayout(new BorderLayout());
			
			JLabel lblSearchedRoomList = new JLabel("Searched Room List:");
			mainPanel.add(lblSearchedRoomList, BorderLayout.NORTH);
			
			searchedRoomList = new JList<Room>();
			mainPanel.add(new JScrollPane(searchedRoomList), BorderLayout.CENTER);									
		}
		
		@Override
		public void update() {
			searchField.setText(command.getQuery());
			searchTypeField.setSelectedIndex(command.getCriteria()-1);
		    Room[] searchResults = command.getSearchResults();

		    if (searchResults != null) {
		    	searchedRoomList.setListData(searchResults);
		    }
		}

		@Override
		public void accept(GUICommand command) {
			this.command = (GUICommand.SearchCommand)command;
			update();
		}
	}
}
