import javax.swing.JPanel;

/**
 * An abstract JPanel represent a command
 * Can be check in, check out or search panel
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public abstract class CommandPanel extends JPanel {
	private static final long serialVersionUID = 1799117341251477063L;

	protected HotelModel hotelModel;
	
	/**
	 * Constructor
	 */
	public CommandPanel(HotelModel model) {
		hotelModel = model;
	}
	
	/**
	 * Set the command object for this panel
	 * The command must be of correct type
	 */
	public abstract void accept(GUICommand command);
	
	/**
	 * Update the panel
	 * Used for synchronizing the view whenever the model is changed
	 */
	public abstract void update();
}
