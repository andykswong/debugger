
import java.util.InputMismatchException;
import java.util.Scanner;

import hkust.comp201.hw.HotelConfig;


/**
 * Console interface for the hotel management system
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class ConsoleUI {
	private boolean pendingQuit = false;
		
	private HotelConfig config;
	private HotelModel model;	

	public ConsoleUI(HotelModel model) {
		this.model = model;
		this.config = model.getConfig();
	}
	
	/**
	 * Quit the console, if it is running
	 */
	public void quit() {
		pendingQuit = true;
	}
	
	/**
	 * Run the hotel management system console
	 */
	public void run() {
		int choice = -1;
		Scanner in = new Scanner(System.in);

		printWelcomeMessage();
		
		while (!pendingQuit) {
			printMenu();
			System.out.print("Choice: ");
			
			try {
				choice = in.nextInt();
			} catch (InputMismatchException e) {
				choice = 0;
			} catch (Exception e) {
				// Quit if error
				choice = 9;
			}
			in.nextLine();
			
			if (choice > 0 && choice <= ConsoleCommand.COMMANDS.length) {
				ConsoleCommand.COMMANDS[choice-1].execute();
			} else {
				System.out.println("Invalid selection!");
			}	
			
		    System.out.println("Press \"Enter\" key to continue...");
	    	in.nextLine();
		}
		
		in.close();
	}
	
	/**
	 * Print the welcome message
	 */
	public void printWelcomeMessage() {
		System.out.println("***********Hotel Room Management System************");
		System.out.printf("Welcome to \"%s\" hotel.\n", config.getName());
		System.out.printf("Today is: %s\n", model.getCurrentDateString());
		System.out.println("***************************************************");
	}
	
	/**
	 * Print the menu for hotel management
	 */
	public void printMenu() {
		System.out.println("Select desired operation:");
		for (int i = 1; i <= ConsoleCommand.COMMANDS.length; ++i) {
		    System.out.printf("%s [%d]\n", ConsoleCommand.COMMANDS[i-1], i);
		}
	}
}
