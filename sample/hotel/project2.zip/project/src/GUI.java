import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JToolBar;
import java.awt.GridLayout;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;

/**
 * The main window for the hotel management system
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class GUI extends JFrame {
	private static final long serialVersionUID = -7466782193912627641L;
	private static final Map<String, String> lookAndFeels;

	private HotelModel model;
	
	private JPanel contentPane;
	private JPanel toolBarPanel;
	
	private GUIView view;
	private GUICommand command;
	private CommandPanel activeCommandPanel;

	private ButtonGroup viewButtonGroup = new ButtonGroup();
	private ButtonGroup cmdButtonGroup = new ButtonGroup();
	
	private JCheckBox chckbxCheckOut;
	private JCheckBox chckbxCheckIn;
	private JCheckBox chckbxSearch;
	
	private JCheckBox chckbxTableView;
	private JCheckBox chckbxListView;
		
	static {
		lookAndFeels = new LinkedHashMap<String, String>();
		lookAndFeels.put("Metal", "javax.swing.plaf.metal.MetalLookAndFeel");
		lookAndFeels.put("Motif", "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		lookAndFeels.put("Windows", "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	}

	/**
	 * Constructor
	 */
	public GUI(HotelModel model) {
		setTitle("Hotel Management System");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
				System.exit(0);
			}
		});
		
		this.model = model;
		view = new ListView(model);
		command = new GUICommand.CheckInCommand(model);
		setupUI();
	}
	
	/**
	 * Invoked when the view or model has changed
	 */
	private void update() {
		activeCommandPanel = view.getPanel(command);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));		
		contentPane.add(toolBarPanel, BorderLayout.NORTH);
		contentPane.add(activeCommandPanel, BorderLayout.CENTER);			
		invalidate();
	    validate();
	    setExtendedState(JFrame.MAXIMIZED_HORIZ | JFrame.MAXIMIZED_VERT);;
	}
	
	/**
	 * Setup the views
	 */
	private void setupUI() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 990, 445);

		setupMenu();	
		setupToolbars();
		
		model.addModelChangeListener(new HotelModel.ModelChangeListener() {
			@Override
			public void roomStateChanged() {
				if (activeCommandPanel != null) {
					// UI update should be called in the UI thread
					EventQueue.invokeLater(new Runnable() {
						public void run() {							
							activeCommandPanel.update();
						}
					});					
				}
			}			
		});
		
		update();
	}
	
	/**
	 * Setup the menu bar
	 */
	private void setupMenu() {
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				// dispatch window closing event to exit
				WindowEvent windowClosing = new WindowEvent(GUI.this,
						WindowEvent.WINDOW_CLOSING);
				GUI.this.dispatchEvent(windowClosing);
			}
		});
		mnFile.add(mntmExit);

		JMenu mnLookAndFeel = new JMenu("Look and Feel");
		menuBar.add(mnLookAndFeel);

		JMenuItem mntmLookAndFeel;
		for (final Entry<String, String> entry : lookAndFeels.entrySet()) {
			mntmLookAndFeel = new JMenuItem(entry.getKey());
			mntmLookAndFeel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					try {
						UIManager.setLookAndFeel(entry.getValue());
						SwingUtilities.updateComponentTreeUI(GUI.this);
					} catch (Exception e) {
						// ignore if not a supported look and feel
					}
				}
			});
			mnLookAndFeel.add(mntmLookAndFeel);
		}
	}

	/**
	 * Setup the tool bar which allows user to choose view and command
	 */
	private void setupToolbars() {
		toolBarPanel = new JPanel();		
		toolBarPanel.setLayout(new GridLayout(1, 2, 0, 0));

		JToolBar viewToolBar = new JToolBar();
		toolBarPanel.add(viewToolBar);
		viewToolBar.setFloatable(false);

		chckbxListView = new JCheckBox("List View");
		chckbxListView.setSelected(true);
		viewToolBar.add(chckbxListView);

		chckbxTableView = new JCheckBox("Table View");
		viewToolBar.add(chckbxTableView);

		JToolBar commandToolBar = new JToolBar();
		commandToolBar.setFloatable(false);
		toolBarPanel.add(commandToolBar);
		
		chckbxCheckIn = new JCheckBox("Check In");
		chckbxCheckIn.setSelected(true);
		commandToolBar.add(chckbxCheckIn);
		
		chckbxCheckOut = new JCheckBox("Check Out");
		commandToolBar.add(chckbxCheckOut);
		
		chckbxSearch = new JCheckBox("Search");
		commandToolBar.add(chckbxSearch);

		viewButtonGroup.add(chckbxListView);
		viewButtonGroup.add(chckbxTableView);
		
		cmdButtonGroup.add(chckbxCheckIn);
		cmdButtonGroup.add(chckbxCheckOut);
		cmdButtonGroup.add(chckbxSearch);
		
		addViewChangeListeners();
		addCommandListeners();
	}
	
	/**
	 * Setup listeners for the list/table view checkbox
	 */
	private void addViewChangeListeners() {
		chckbxListView.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				view = new ListView(model);
				update();
			}			
		});

		chckbxTableView.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {				
				view = new TableView(model);
				update();
			}			
		});
	}

	/**
	 * Setup the listeners for choosing the command (check in / check out /
	 * search)
	 */
	private void addCommandListeners() {
		chckbxCheckIn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				command = new GUICommand.CheckInCommand(model);
				update();
			}			
		});
		
		chckbxCheckOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				command = new GUICommand.CheckOutCommand(model);
				update();
			}			
		});
		
		chckbxSearch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				command = new GUICommand.SearchCommand(model);
				update();
			}			
		});
	}
}
