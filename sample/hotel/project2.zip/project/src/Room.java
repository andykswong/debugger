import hkust.comp201.hw.HotelConfig;

import java.text.DateFormat;
import java.util.Date;

/**
 * Model of a room in the hotel
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class Room {
	private String ethernetAddr = null;
	private Occupant occupant = null;
	private int floor, room;
	private int capacity;
	private short type;
	private double rate;
	private Date checkInDate = null;
	
	/**
	 * Construct a room from floor and room number
	 * @param floor floor number
	 * @param room room number 
	 */
	public Room(int floor, int room, int capacity, short type, double rate) {
		this.floor = floor;
		this.room = room;
		this.capacity = capacity;
		this.type = type;
		this.rate = rate;
	}
	
	/**
	 * Get room number in string (format: #-#)
	 */
	public String getRoomNo() {
		return String.format("%d-%d", floor, room);
	}
	
	/**
	 * Get capacity of the room
	 */
	public int getCapacity() {
		return capacity;
	}
	
	/**
	 * Get rate of the room
	 */
	public double getRate() {
		return rate;
	}
	
	/**
	 * Get type of room, see HotelConfig for room types
	 * @see HotelConfig
	 */
	public short getType() {
		return type;
	}
	
	/**
	 * Set check in date of the room
	 * @param date check in date
	 */
	public void setCheckInDate(Date date) {
		checkInDate = date;
	}
	
	/**
	 * Get check in date of room
	 * @return check in date, null if room is empty
	 */
	public Date getCheckInDate() {
		return checkInDate;
	}
	
	/**
	 * Check if room is occupied
	 */
	public boolean isOccupied() {
		return occupant != null;
	}
	
	/**
	 * Set occupant of room
	 * @param occupant new occupant of room, or null for no occupant
	 */
	public void setOccupant(Occupant occupant) {
		this.occupant = occupant;
	}
	
	/**
	 * Get occupant of room
	 * @return occupant of room
	 */
	public Occupant getOccupant() {
		return occupant;
	}

	/**
	 * Set the Ethernet address of data service
	 * @param ethernetAddr Ethernet address, or null for not using the service
	 */
	public void setDataService(String ethernetAddr) {
		this.ethernetAddr = ethernetAddr;
	}
	
	/**
	 * Get the Ethernet address of data service
	 */
	public String getDataService() {
		return ethernetAddr;
	}

	/**
	 * Return the string output of the room details
	 */
	@Override
	public String toString() {
		StringBuilder content = new StringBuilder();
		content.append(String.format("Room No: %s Room Type: %s, Capacity: %d, Rate: %.1f, \n", getRoomNo(), HotelUtil.getRoomTypeName(getType()), getCapacity(), getRate()));
		if (getType() != HotelConfig.STANDARD_ROOM) {
			String dataService = getDataService();
			if (dataService != null) {
				content.append(String.format("Data service: In used (Ethernet address: %s), \n", getDataService()));
			} else {
				content.append("Data service: Not in used, \n");
			}
		}
		if (isOccupied()) {
			Occupant occupant = getOccupant();
			DateFormat formatter = Hotel.getInstance().getModel().getDateFormat();			
			content.append(String.format("Occupant: %s, \nDate of checking in: %s\n", occupant.toString(), formatter.format(getCheckInDate())));
		} else {
			content.append("Occupant: None\n");
		}
		
		return content.toString();
	}	
}