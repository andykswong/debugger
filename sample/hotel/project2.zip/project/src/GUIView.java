/**
 * A view for the GUI. Provide a common interface for both ListView and
 * TableView
 * @author Wong Kwok Shiu
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public abstract class GUIView {
	protected HotelModel hotelModel;
	
	/**
	 * Get the panel for check in
	 */
	public abstract CommandPanel getCheckInPanel();
	
	/**
	 * Get the panel for check out
	 */
	public abstract CommandPanel getCheckOutPanel();
	
	/**
	 * Get the panel for searching
	 */
	public abstract CommandPanel getSearchPanel();
	
	/**
	 * Constructor
	 */
	public GUIView(HotelModel model) {
		hotelModel = model;
	}

	/**
	 * Get the CommandPanel of this view which corresponds to the given
	 * GUICommand 
	 * @param command the active command
	 * @return the corresponding CommandPanel
	 */
	public CommandPanel getPanel(GUICommand command) {
		if (command != null) {
			return command.getPanel(this);
		}
		
		return null;
	}
}
