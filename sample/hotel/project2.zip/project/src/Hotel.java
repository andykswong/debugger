import java.awt.EventQueue;

import hkust.comp201.hw.HotelConfig;
import hkust.comp201.hw.HotelConfigException;

/**
 * Entry class for the hotel management system
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class Hotel {	
	private static Hotel hotelInstance;
	
	private HotelConfig config;
	private HotelModel model;
	
	private ConsoleUI consoleUI;
	private GUI gui;
	
	private Thread consoleThread;
	
	/**
	 * Main entry function
	 */
	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("Hotel configuration XML file not specified!");
			return;
		}
		
		HotelConfig config;
		try {
			config = new HotelConfig(args[0]);
		} catch (HotelConfigException e) {
			System.out.println("Invalid hotel configuration XML file!");
			return;
		}

		hotelInstance = new Hotel(config);
		hotelInstance.run();
	}
	
	/**
	 * Get an instance of the Hotel class
	 * @return the singleton Hotel instance
	 */
	public static Hotel getInstance() {
		return hotelInstance;
	}
	
	/**
	 * Constructor, protected for singleton pattern
	 * @param config hotel config
	 */
	protected Hotel(HotelConfig config) {
		this.config = config;
		model = new HotelModel(config);
		consoleUI = new ConsoleUI(model);		
		consoleThread = new Thread(new Runnable() {
			@Override
			public void run() {
				consoleUI.run();
			}			
		});
	}

	/**
	 * Run the hotel management system. It creates a console and a GUI interface.
	 */
	public void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui = new GUI(model);
					gui.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		consoleThread.start();
	}
	
	/**
	 * Quit the hotel system, if it is running
	 */
	public void quit() {
		consoleUI.quit();
		gui.dispose();
	}

	/**
	 * Get the hotel model
	 * @return the hotel model
	 */
	public HotelModel getModel() {
		return model;
	}

	/**
	 * Get the hotel config
	 * @return the hotel config
	 */
	public HotelConfig getConfig() {
		return config;
	}
}
