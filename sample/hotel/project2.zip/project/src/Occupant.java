
/**
 * Model of an occupant of a hotel room
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class Occupant {
	public static final short STANDARD = 1, BUSINESS = 2;
	private String name, id, company = null;
	private short type;
	
	/**
	 * Construct a standard occupant
	 * @param name name of occupant
	 * @param id id of occupant
	 */
	public Occupant(String name, String id) {
		type = STANDARD;
		this.name = name;
		this.id = id;
	}
	
	/**
	 * Construct a business occupant
	 * @param name name of occupant
	 * @param id id of occupant
	 * @param company company of occupant
	 */
	public Occupant(String name, String id, String company) {
		this.name = name;
		this.id = id;
		this.company = company;
		type = BUSINESS;
	}
	
	/**
	 * Get ID of occupant
	 */
	public String getID() {
		return id;
	}
	
	/**
	 * Get name of occupant
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Get company name of occupant
	 */
	public String getCompany() {
		return company;
	}
	
	/**
	 * Get type of occupant
	 * @return STANDARD or BUSINESS, depends on occupant type
	 */
	public short getType() {
		return type;
	}
	
	/**
	 * Get the string representation of occupant
	 */
	@Override
	public String toString() {
		if (type == STANDARD) {
			return String.format("<Name: %s, Member ID: %s>", getName(), getID());
		} else {
			return String.format("<Name: %s, Member ID: %s, Company: %s>", getName(), getID(), getCompany());
		}
	}
}