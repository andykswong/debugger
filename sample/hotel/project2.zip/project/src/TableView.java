import hkust.comp201.hw.HotelConfig;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;

import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormat;
import java.util.List;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;

/**
 * The table-based implementation of GUI view
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class TableView extends GUIView {
	/**
	 * Constructor
	 */
	public TableView(HotelModel model) {
		super(model);
	}

	@Override
	public CommandPanel getCheckInPanel() {
		return new CheckInPanel(hotelModel);
	}
	
	/**
	 * Panel for the check in interface using table
	 */
	private static class CheckInPanel extends CommandPanel {
		private static final long serialVersionUID = 5587155752776526432L;

		private GUICommand.CheckInCommand command;
		
		private JTextField IDField;
		private JTextField nameField;
		private JComboBox<String> typeField;
		private JTextField companyField;
		private JTextField checkInDateField;
		private JComboBox<String> dataServiceField;
		private JTextField eternetField;

		private JTable availableRoomTable = new JTable();
		private Room[] availableRooms;

		private JPanel optionsPanel;

		/**
		 * Constructor
		 */
		public CheckInPanel(HotelModel model) {
			super(model);
			command = new GUICommand.CheckInCommand(model);
			setupUI();
			update();
		}

		/**
		 * Setup the UI for this panel
		 */
		private void setupUI() {
			setLayout(new BorderLayout());

			optionsPanel = new JPanel();
			add(optionsPanel, BorderLayout.EAST);
			optionsPanel.setLayout(new BorderLayout());
			optionsPanel.setBorder(new BevelBorder(1));

			JButton btnCheckIn = new JButton("Check In");
			optionsPanel.add(btnCheckIn, BorderLayout.SOUTH);
			btnCheckIn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (command.getSelectedRoom() == null) {
						JOptionPane.showMessageDialog(CheckInPanel.this,
								"No room is selected", "Input Error",
								JOptionPane.INFORMATION_MESSAGE);
						return;
					}

					try {
						command.exec();
					} catch (HotelModel.InvalidActionException e) {
						JOptionPane.showMessageDialog(CheckInPanel.this, e.getMessage(),
								"Input Error", JOptionPane.INFORMATION_MESSAGE);
					}
					
					update();
				}
			});

			setupRoomInfoPanel();
			setupRoomList();
		}

		/**
		 * Setup the panel for input
		 */
		private void setupRoomInfoPanel() {
			JPanel mainPanel = new JPanel();
			optionsPanel.add(mainPanel, BorderLayout.CENTER);

			JPanel contentPanel = new JPanel();
			mainPanel.add(contentPanel);
			contentPanel.setBorder(new EmptyBorder(0, 5, 0, 5));
			contentPanel.setLayout(new GridLayout(11, 2, 1, 1));

			// Occupant Details

			JLabel lblOccupantDetails = new JLabel("Occupant Details:");
			contentPanel.add(lblOccupantDetails);

			Component rigidArea_2 = Box.createRigidArea(null);
			contentPanel.add(rigidArea_2);

			JLabel lblId = new JLabel("ID: ");
			contentPanel.add(lblId);

			IDField = new JTextField();
			IDField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					String id = IDField.getText();
					if (HotelUtil.isValidMemberID(id)) {
						command.setID(id);
					} else if (!"".equals(id)) {
						IDField.setText(command.getID());
						JOptionPane
								.showMessageDialog(
										CheckInPanel.this,
										"The format of the inputted ID is invalid. It should be an English letter followed by exactly 8 digits",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			contentPanel.add(IDField);

			JLabel lblName = new JLabel("Name:");
			contentPanel.add(lblName);

			nameField = new JTextField();
			nameField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					command.setName(nameField.getText());
				}
			});
			contentPanel.add(nameField);

			JLabel lblType = new JLabel("Type:");
			contentPanel.add(lblType);

			typeField = new JComboBox<String>();
			typeField.setModel(new DefaultComboBoxModel<String>(new String[] {
					"Standard", "Business" }));
			typeField.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					command.setType(typeField.getSelectedIndex() == 0 ? Occupant.STANDARD
							: Occupant.BUSINESS);
					updateDataService();
				}
			});
			contentPanel.add(typeField);

			JLabel lblCompany = new JLabel("Company:");
			contentPanel.add(lblCompany);

			companyField = new JTextField();
			companyField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					command.setCompany(companyField.getText());
				}
			});			
			contentPanel.add(companyField);

			Component rigidArea1 = Box.createRigidArea(null);
			contentPanel.add(rigidArea1);

			Component rigidArea2 = Box.createRigidArea(null);
			contentPanel.add(rigidArea2);

			// Occupation details

			JLabel lblOccupationDetails = new JLabel("Occupation Details:");
			contentPanel.add(lblOccupationDetails);

			Component rigidArea3 = Box.createRigidArea(null);
			contentPanel.add(rigidArea3);

			JLabel lblDateOfCheckin = new JLabel(
					"Date of Check-in (dd-MM-yyyy):");
			contentPanel.add(lblDateOfCheckin);

			checkInDateField = new JTextField();
			checkInDateField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					String date = checkInDateField.getText();
					DateFormat formatter = hotelModel.getAltDateFormat();
					try {
						command.setCheckInDate(formatter.parse(date));
					} catch (Exception ex) {
						checkInDateField.setText(formatter.format(command
								.getCheckInDate()));
						JOptionPane
								.showMessageDialog(
										CheckInPanel.this,
										"The format of the inputted check-in date is invalid",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			contentPanel.add(checkInDateField);

			JLabel lblIsDataService = new JLabel("Is Data Service Required?");
			contentPanel.add(lblIsDataService);

			dataServiceField = new JComboBox<String>();
			dataServiceField.setModel(new DefaultComboBoxModel<String>(
					new String[] { "Yes", "No" }));
			dataServiceField.setEnabled(false);
			dataServiceField.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					if (dataServiceField.getSelectedItem().equals("Yes")) {
						command.setDataRequired(true);
					} else {
						command.setDataRequired(false);
					}
					updateDataService();
				}
			});
			contentPanel.add(dataServiceField);

			JLabel lblEthernetAddress = new JLabel("Ethernet Address:");
			contentPanel.add(lblEthernetAddress);

			eternetField = new JTextField();
			eternetField.setEnabled(false);
			eternetField.addFocusListener(new FocusAdapter() {
				public void focusLost(FocusEvent e) {
					String addr = eternetField.getText();
					if (HotelUtil.isValidEthernetAddress(addr)) {
						command.setEthernetAddress(addr);
					} else {
						JOptionPane
								.showMessageDialog(
										CheckInPanel.this,
										"The format of the inputted ethernet address is invalid",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
						eternetField.setText(command.getEthernetAddress());
					}
				}
			});
			contentPanel.add(eternetField);
		}

		/**
		 * Setup the table of available rooms
		 */
		private void setupRoomList() {
			JPanel roomInfo = new JPanel();
			add(roomInfo, "Center");
			roomInfo.setLayout(new BorderLayout());
			roomInfo.add(new JLabel("Available Room List:"), "North");

			availableRoomTable = new JTable();
			roomInfo.add(new JScrollPane(availableRoomTable), "Center");

			availableRoomTable.setSelectionMode(0);
			final ListSelectionModel model = availableRoomTable
					.getSelectionModel();
			model.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent e) {
					int index = model.getMinSelectionIndex();
					if (index != -1) {
						Room room = availableRooms[index];
						if (room != null) {
							command.setSelectedRoom(room);
							updateDataService();
						}
					}
				}
			});
		}

		@Override
		public void update() {
			List<Room> list = hotelModel.findRoomsByAvailability(true);
			availableRooms = list.toArray(new Room[list.size()]);
			availableRoomTable.setModel(new AbstractTableModel() {
				private static final long serialVersionUID = 4722964980478958991L;

				String[] headers = { "Room No", "Room Type", "Capacity",
						"Rate", "Data Service" };

				public int getRowCount() {
					return CheckInPanel.this.availableRooms.length;
				}

				public int getColumnCount() {
					return this.headers.length;
				}

				public Object getValueAt(int r, int c) {
					Room room = CheckInPanel.this.availableRooms[r];
					if (room == null) {
						return null;
					}
					switch (c) {
					case 0:
						return room.getRoomNo();
					case 1:
						return HotelUtil.getRoomTypeName(room.getType());
					case 2:
						return room.getCapacity();
					case 3:
						return room.getRate();
					case 4:
						if (room.getType() == HotelConfig.STANDARD_ROOM) {
							return "N/A";
						}
						return "Not in used";
					}
					return "";
				}

				public String getColumnName(int c) {
					return this.headers[c];
				}
			});
			
			
			Room selectedRoom = command.getSelectedRoom();
			if (selectedRoom != null) {
				int index = list.indexOf(selectedRoom);
				if (index >= 0) {
					availableRoomTable.setRowSelectionInterval(index, index);
				} else {
					command.setSelectedRoom(null);
				}
			}
			
			IDField.setText(command.getID());
			nameField.setText(command.getName());
		    typeField.setSelectedIndex(command.getType() == Occupant.STANDARD ? 0 : 1);
		    companyField.setText(command.getCompany());
		    checkInDateField.setText(hotelModel.getAltDateFormat().format(command.getCheckInDate()));
		    updateDataService();
		    eternetField.setText(command.getEthernetAddress());
		}

		/**
		 * Update only the widgets related to data service
		 */
		private void updateDataService() {
			Room room = command.getSelectedRoom();
			if (room == null || room.getType() == HotelConfig.STANDARD_ROOM
					|| command.getType() == Occupant.STANDARD) {
				dataServiceField.setEnabled(false);
				eternetField.setEnabled(false);
				if (dataServiceField.getSelectedItem().equals("Yes")) {
					dataServiceField.setSelectedItem("No");
				}
				command.setDataRequired(false);
			} else {
				dataServiceField.setEnabled(true);
				if (command.isDataRequired()) {
					if (dataServiceField.getSelectedItem().equals("No")) {
						dataServiceField.setSelectedItem("Yes");
					}
					eternetField.setEnabled(true);
				} else {
					if (dataServiceField.getSelectedItem().equals("Yes")) {
						dataServiceField.setSelectedItem("No");
					}
					eternetField.setEnabled(false);
				}
			}
		}

		@Override
		public void accept(GUICommand command) {
			this.command = (GUICommand.CheckInCommand)command;
			update();
		}
	}

	@Override
	public CommandPanel getCheckOutPanel() {
		return new CheckOutPanel(hotelModel);
	}

	/**
	 * Panel for check out interface using table
	 */
	private static class CheckOutPanel extends CommandPanel {
		private static final long serialVersionUID = 6818461040126775134L;

		private GUICommand.CheckOutCommand command;
		
		private JPanel optionsPanel;
		private JTextField checkOutDateField;

		private JTable occupiedRoomTable = new JTable();
		private Room[] occupiedRooms;

		/**
		 * Constructor
		 */
		public CheckOutPanel(HotelModel model) {
			super(model);
			command = new GUICommand.CheckOutCommand(model);
			setupUI();
			update();
		}

		/**
		 * Setup the UI for this panel
		 */
		private void setupUI() {
			setLayout(new BorderLayout());

			optionsPanel = new JPanel();
			add(optionsPanel, BorderLayout.NORTH);
			optionsPanel.setLayout(new GridLayout(1, 2, 1, 1));
			optionsPanel.setBorder(new BevelBorder(1));

			setupCheckOutPanel();
			setupRoomList();
		}

		/**
		 * Setup the input panel
		 */
		private void setupCheckOutPanel() {
			JPanel checkOutDatePanel = new JPanel();
			optionsPanel.add(checkOutDatePanel);

			checkOutDatePanel
					.add(new JLabel("Date of Check-out (dd-MM-yyyy):"));
			checkOutDateField = new JTextField(15);
			checkOutDateField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					String date = checkOutDateField.getText();
					DateFormat formatter = hotelModel.getAltDateFormat();
					try {
						command.setCheckOutDate(formatter.parse(date));
					} catch (Exception ex) {
						checkOutDateField.setText(formatter.format(command
								.getCheckOutDate()));
						JOptionPane
								.showMessageDialog(
										CheckOutPanel.this,
										"The format of the inputted check-out date is invalid",
										"Input Error",
										JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			checkOutDatePanel.add(this.checkOutDateField);

			JToolBar checkOutToolbar = new JToolBar();
			optionsPanel.add(checkOutToolbar);

			JButton btnCheckOut = new JButton("Check Out");
			btnCheckOut.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (command.getSelectedRoom() == null) {
						JOptionPane.showMessageDialog(CheckOutPanel.this,
								"No room is selected", "Input Error",
								JOptionPane.INFORMATION_MESSAGE);
						return;
					}
					
					try {
						command.exec();
					} catch (HotelModel.InvalidActionException e) {
						JOptionPane.showMessageDialog(CheckOutPanel.this, e.getMessage(),
								"Input Error", JOptionPane.INFORMATION_MESSAGE);
					}
					
					update();
				}
			});
			checkOutToolbar.add(btnCheckOut);
		}

		/**
		 * Setup the table of occupied rooms
		 */
		private void setupRoomList() {
			JPanel roomInfo = new JPanel();
			add(roomInfo, "Center");
			roomInfo.setLayout(new BorderLayout());
			roomInfo.add(new JLabel("Occupied Room List:"), "North");

			occupiedRoomTable = new JTable();
			roomInfo.add(new JScrollPane(occupiedRoomTable), "Center");

			occupiedRoomTable.setSelectionMode(0);
			final ListSelectionModel model = occupiedRoomTable
					.getSelectionModel();

			model.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					int index = model.getMinSelectionIndex();
					if (index != -1) {
						Room room = occupiedRooms[index];
						if (room != null) {
							command.setSelectedRoom(room);
						}
					}
				}
			});
		}

		@Override
		public void update() {
			List<Room> list = hotelModel.findRoomsByAvailability(false);
			occupiedRooms = list.toArray(new Room[list.size()]);
			occupiedRoomTable.setModel(new AbstractTableModel() {
				private static final long serialVersionUID = 5361761061531002527L;

				String[] headers = { "Room No", "Room Type", "Capacity",
						"Rate", "Data Service", "Ethernet Address",
						"Occupant Name", "Occupant Type", "Member ID",
						"Company", "Check-in Date" };

				public int getRowCount() {
					return CheckOutPanel.this.occupiedRooms.length;
				}

				public int getColumnCount() {
					return this.headers.length;
				}

				public Object getValueAt(int r, int c) {
					Room room = CheckOutPanel.this.occupiedRooms[r];
					if (room == null) {
						return null;
					}
					Occupant occupant = room.getOccupant();
					switch (c) {
					case 0:
						return room.getRoomNo();
					case 1:
						return HotelUtil.getRoomTypeName(room.getType());
					case 2:
						return room.getCapacity();
					case 3:
						return new Double(room.getRate());
					case 4:
						if (room.getType() == 1) {
							return "N/A";
						} else if (room.getDataService() != null) {
							return "In used";
						}
						return "Not in used";
					case 5:
						return room.getDataService();
					case 6:
						return occupant.getName();
					case 7:
						return occupant.getType();
					case 8:
						return occupant.getID();
					case 9:
						return occupant.getCompany();
					case 10:
						return hotelModel.getDateFormat().format(
								room.getCheckInDate());
					}
					return "";
				}

				public String getColumnName(int c) {
					return this.headers[c];
				}
			});
			
			Room selectedRoom = command.getSelectedRoom();
			if (selectedRoom != null) {
				int index = list.indexOf(selectedRoom);
				if (index >= 0) {
					this.occupiedRoomTable.setRowSelectionInterval(index, index);
				} else {
					command.setSelectedRoom(null);
				}
			}
			this.checkOutDateField.setText(hotelModel.getAltDateFormat()
					.format(command.getCheckOutDate()));
		}

		@Override
		public void accept(GUICommand command) {
			this.command = (GUICommand.CheckOutCommand)command;
			update();
		}
	}

	@Override
	public CommandPanel getSearchPanel() {
		return new SearchPanel(hotelModel);
	}

	/**
	 * Panel for searching using table
	 */
	private static class SearchPanel extends CommandPanel {
		private static final long serialVersionUID = 5595994174022732730L;

		private GUICommand.SearchCommand command;
		
		private JPanel optionsPanel;
		private JTable searchedRoomTable = new JTable();

		private JTextField searchField;
		private JComboBox<String> searchTypeField;
		
		/**
		 * Constructor
		 */
		public SearchPanel(HotelModel model) {
			super(model);
			command = new GUICommand.SearchCommand(model);
			setupUI();
			update();
		}

		/**
		 * Setup the UI for this panel
		 */
		private void setupUI() {
			setLayout(new BorderLayout());

			optionsPanel = new JPanel();
			optionsPanel.setLayout(new BorderLayout());
			add(optionsPanel, BorderLayout.NORTH);

			setupSearchDetails();
			setupRoomList();
		}

		private void setupSearchDetails() {
			JPanel searchDetailsPanel = new JPanel();
			optionsPanel.add(searchDetailsPanel, BorderLayout.CENTER);
			searchDetailsPanel.setLayout(new GridLayout(1, 2, 1, 1));
			searchDetailsPanel.setBorder(new BevelBorder(1));

			JPanel searchCriteriaPanel = new JPanel();
			searchCriteriaPanel.setLayout(new GridLayout(2, 2, 1, 1));

			JPanel containerPanel = new JPanel();
			containerPanel.add(searchCriteriaPanel);
			searchDetailsPanel.add(containerPanel);

			JLabel lblSearchField = new JLabel("Search Field:");
			searchCriteriaPanel.add(lblSearchField);

			searchField = new JTextField(15);
			searchField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					command.setQuery(searchField.getText());
				}
			});
			searchCriteriaPanel.add(searchField);

			JLabel lblType = new JLabel("Type:");
			searchCriteriaPanel.add(lblType);

			searchTypeField = new JComboBox<String>();
			searchTypeField.setModel(new DefaultComboBoxModel<String>(
					new String[] { "Name", "ID", "Type", "Company" }));
			searchTypeField.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					command.setCriteria((short) (searchTypeField
							.getSelectedIndex() + 1));
				}
			});
			searchCriteriaPanel.add(searchTypeField);

			JToolBar searchToolbar = new JToolBar();
			searchDetailsPanel.add(searchToolbar);

			JButton btnSearch = new JButton("Search");
			btnSearch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					command.exec();
					update();
				}
			});
			
			searchToolbar.add(btnSearch);
		}

		private void setupRoomList() {
			JPanel roomInfo = new JPanel();
			add(roomInfo, "Center");
			roomInfo.setLayout(new BorderLayout());
			roomInfo.add(new JLabel("Searched Room List:"), BorderLayout.NORTH);

			searchedRoomTable = new JTable();
			roomInfo.add(new JScrollPane(searchedRoomTable),
					BorderLayout.CENTER);
		}

		@Override
		public void update() {
			searchedRoomTable.setModel(new AbstractTableModel() {
				private static final long serialVersionUID = 3074849848454755854L;

				String[] headers = { "Room No", "Room Type", "Capacity",
						"Rate", "Data Service", "Ethernet Address",
						"Occupant Name", "Occupant Type", "Member ID",
						"Company", "Check-in Date" };
				
				Room[] searchResults = command.getSearchResults();

				public int getRowCount() {
					return searchResults.length;
				}

				public int getColumnCount() {
					return this.headers.length;
				}

				public Object getValueAt(int r, int c) {
					Room room = searchResults[r];
					if (room == null) {
						return null;
					}
					Occupant occupant = room.getOccupant();
					switch (c) {
					case 0:
						return room.getRoomNo();
					case 1:
						return HotelUtil.getRoomTypeName(room.getType());
					case 2:
						return room.getCapacity();
					case 3:
						return new Double(room.getRate());
					case 4:
						if (room.getType() == 1) {
							return "N/A";
						} else if (room.getDataService() != null) {
							return "In used";
						}
						return "Not in used";
					case 5:
						return room.getDataService();
					case 6:
						return occupant.getName();
					case 7:
						return occupant.getType();
					case 8:
						return occupant.getID();
					case 9:
						return occupant.getCompany();
					case 10:
						return hotelModel.getDateFormat().format(
								room.getCheckInDate());
					}
					return "";
				}

				public String getColumnName(int c) {
					return this.headers[c];
				}
			});
			
			searchField.setText(command.getQuery());
		    searchTypeField.setSelectedIndex(command.getCriteria()-1);
		}

		@Override
		public void accept(GUICommand command) {
			this.command = (GUICommand.SearchCommand)command;
			update();
		}
	}
}
