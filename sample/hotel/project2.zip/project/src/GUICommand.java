import java.util.Date;

/**
 * A command in the hotel system GUI
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public interface GUICommand {
	/**
	 * Get the correct command panel corresponds to this command
	 * @param view the view to be used (list / table)
	 * @return the suitable CommandPanel
	 */
	CommandPanel getPanel(GUIView view); 

	/**
	 * Execute the command. This can modify the HotelModel and throw exception
	 * when the command fails to execute
	 */
	void exec() throws Exception; 
	
	/**
	 * Command for check in
	 */
	public static class CheckInCommand implements GUICommand {
		private HotelModel hotelModel;
		
		private String id;
		private String name = "";
		private short type = Occupant.STANDARD;
		private String company = "";
		private Date checkInDate;
		private boolean isDataRequired = false;
		private String ethernetAddr = "00:00:00:00:00:00";
		private Room room;

		/**
		 * Constructor
		 */
		public CheckInCommand(HotelModel model) {
			hotelModel = model;
			id = model.getRandomID();
			checkInDate = model.getCurrentDate();
		}

		/**
		 * Clear all inputs. Used after the command executes correctly
		 */
		private void clear() {			
			id = hotelModel.getRandomID();
			checkInDate = hotelModel.getCurrentDate();
			name = "";
			type = Occupant.STANDARD;
			company = "";
			isDataRequired = false;
			ethernetAddr = "00:00:00:00:00:00";
			room = null;
		}

		@Override
		public CommandPanel getPanel(GUIView view) {
			CommandPanel p = view.getCheckInPanel();
			p.accept(this);
			return p;
		}

		public String getID() {
			return id;
		}

		public void setID(String id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public short getType() {
			return type;
		}

		public void setType(short type) {
			this.type = type;
		}

		public String getCompany() {
			return company;
		}

		public void setCompany(String company) {
			this.company = company;
		}

		public Date getCheckInDate() {
			return checkInDate;
		}

		public void setCheckInDate(Date checkInDate) {
			this.checkInDate = checkInDate;
		}
		
		public boolean isDataRequired() {
			return isDataRequired;
		}
		
		public void setDataRequired(boolean required) {
			isDataRequired = required;
		}

		public String getEthernetAddress() {
			return ethernetAddr;
		}

		public void setEthernetAddress(String ethernetAddr) {
			this.ethernetAddr = ethernetAddr;
		}

		public Room getSelectedRoom() {
			return room;
		}

		public void setSelectedRoom(Room room) {
			this.room = room;
		}
		
		@Override
		public void exec() throws HotelModel.InvalidActionException {
			if (type == Occupant.BUSINESS) {
				hotelModel.checkIn(room, checkInDate, name, id, company,
						(isDataRequired ? ethernetAddr : null));
			} else {
				hotelModel.checkIn(room, checkInDate, name, id);
			}
			clear();
		}
	}
	
	/**
	 * Command for check out
	 */
	public static class CheckOutCommand implements GUICommand {
		private HotelModel hotelModel;
		
		private Date checkOutDate;
		private Room selectedRoom;

		/**
		 * Constructor
		 */
		public CheckOutCommand(HotelModel model) {
			hotelModel = model;
			checkOutDate = model.getCurrentDate();
		}

		@Override
		public CommandPanel getPanel(GUIView view) {
			CommandPanel p = view.getCheckOutPanel();
			p.accept(this);
			return p;
		}		
		
		/**
		 * Clear all inputs. Used after the command executes correctly
		 */
		private void clear() {
			selectedRoom = null;
			checkOutDate = hotelModel.getCurrentDate();
		}

		public Room getSelectedRoom() {
			return this.selectedRoom;
		}

		public void setSelectedRoom(Room selectedRoom) {
			this.selectedRoom = selectedRoom;
		}

		public Date getCheckOutDate() {
			return this.checkOutDate;
		}

		public void setCheckOutDate(Date checkOutDate) {
			this.checkOutDate = checkOutDate;
		}

		@Override
		public void exec() throws HotelModel.InvalidActionException {
			hotelModel.checkOut(selectedRoom, checkOutDate);
			clear();
		}
	}
	
	/**
	 * Command for searching
	 */
	public static class SearchCommand implements GUICommand {
		private HotelModel hotelModel;
		
		private String query = "";
		private short criteria = HotelModel.CRITERIA_NAME;
		private Room[] searchResults = new Room[0];

		/**
		 * Constructor
		 */
		public SearchCommand(HotelModel model) {
			hotelModel = model;
		}
		
		/**
		 * Can be called after exec() to get the search results
		 * @return the matched rooms
		 */
		public Room[] getSearchResults() { 
			return searchResults; 
		} 

		public short getCriteria() {
			return criteria;
		}

		public void setCriteria(short criteria) {
			this.criteria = criteria;
		}

		public String getQuery() {
			return query;
		}

		public void setQuery(String query) {
			this.query = query;
		}
		
		@Override
		public CommandPanel getPanel(GUIView view) {
			CommandPanel p = view.getSearchPanel();
			p.accept(this);
			return p;
		}

		@Override
		public void exec() {
			searchResults = hotelModel.findRoomsByOccupant(criteria, query)
					.toArray(searchResults);
		}
	}
}
