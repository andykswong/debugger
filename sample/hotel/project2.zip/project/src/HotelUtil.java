import java.util.Date;

import hkust.comp201.hw.HotelConfig;

/**
 * A utility class providing useful functions and constants
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class HotelUtil {	
	/**
	 * An interface for defining a predicate on a value
	 * @param <T> type of input
	 */
	public static interface Predicate<T> { 
		/**
		 * Check if a value can satisfy the predicate
		 * @param val value to be checked
		 * @return whether the value satisfies the predicate
		 */
		boolean apply(T val); 
	}
	
	public static final String MSG_INVALID_SELECTION = "Invalid selection!";
	public static final String MSG_INVALID_FORMAT = "Format not correct.";
	public static final String MSG_INVALID_ROOM = "Room selected doesn't exist.";
	public static final String MSG_INVALID_DATE = "Check-out date must be after check-in date.";
	public static final String MSG_ROOM_OCCUPIED = "Room is occupied.";
	public static final String MSG_ROOM_EMPTY = "Room is not occupied.";
			
	/**
	 * Calculate the number of days between 2 dates
	 * @return (to - from)
	 */
	public static long daysDiff(Date from, Date to) {
	    return daysDiff(from.getTime(), to.getTime());
	}

	/**
	 * Calculate the number of days between 2 time stamps
	 * @return (to - from)
	 */
	public static long daysDiff(long from, long to) {
	    return Math.round((to - from) / 86400000F); // 1000 * 60 * 60 * 24
	}
	
	/**
	 * Check whether the given Ethernet address is valid 
	 * Format: xx:xx:xx:xx:xx:xx, where x = [0-9a-eA-E]
	 * @param addr the Ethernet address to be validated
	 * @return true if the address is valid, false otherwise
	 */
	public static boolean isValidEthernetAddress(String addr) {
		return addr.matches("^[0-9a-eA-E]{2}(:[0-9a-eA-E]{2}){5}");
	}
	
	/**
	 * Check whether the given member ID is valid
	 * Format: adddddddd, where a = [a-zA-Z], d = [0-9]
	 * @param id the member ID to be validated
	 * @return true if the ID is valid, false otherwise
	 */
	public static boolean isValidMemberID(String id) {
		return id.matches("^[a-zA-Z][0-9]{8}$");
	}
	
	/**
	 * Convert room type number to its name
	 * @param roomType Room type number as defined by HotelConfig
	 * @see HotelConfig
	 * @return Either "Standard", "Presidential", "Executive" or null
	 */
	public static String getRoomTypeName(short roomType) {
		switch (roomType) {
		case HotelConfig.STANDARD_ROOM:
			return "Standard";
		case HotelConfig.PRESIDENTIAL_ROOM:
			return "Presidential";
		case HotelConfig.EXECUTIVE_ROOM:
			return "Executive";
		default:
			return null;
		}
	}

	/**
	 * Convert occupant type to string
	 * @return Either "Standard", "Business", or null
	 */
	public static String getOccupantTypeName(short occupantType) {
		switch (occupantType) {
		case Occupant.STANDARD:
			return "Standard";
		case Occupant.BUSINESS:
			return "Business";
		default:
			return null;
		}
	}
	
	/**
	 * Print the details for the given room
	 * @param room the room to be printed out
	 */
	public static void printRoomDetails(Room room) {
		System.out.println("======================================================================");
		System.out.print(room.toString());
		System.out.println("======================================================================");
	}
}
