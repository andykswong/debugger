import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import hkust.comp201.hw.HotelConfig;

/**
 * Model for the hotel system
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class HotelModel {
	/**
	 * An exception thrown when there is error when checking in or out
	 */
	public static class InvalidActionException extends Exception {
		private static final long serialVersionUID = -3525870336346678343L;

		public InvalidActionException(String errMsg) {
			super(errMsg);
		}
	}
	
	/**
	 * ID of criteria for searching occupants
	 */
	public static final short CRITERIA_NAME = 1, CRITERIA_MEMBER_ID = 2;
	
	private Room[][] rooms;
	private Date currentDate = new Date();
	private SimpleDateFormat dateFormatter = new SimpleDateFormat("d-M-yyyy");

	/**
	 * Constructor
	 * @param config Config of the hotel
	 */
	public HotelModel(HotelConfig config) {
		rooms = new Room[config.getNumFloors()][];

		int floor, room;
		for (int i = 0; i < rooms.length; ++i) {
			rooms[i] = new Room[config.getNumRoomsInFloor(i+1)];
			
			for (int j = 0; j < rooms[i].length; ++j) {
				floor = i + 1;
				room = j + 1;
				rooms[i][j] = new Room(floor, room, config.getRoomCapacity(floor, room), config.getRoomType(floor, room), config.getRoomRate(floor, room));
			}
		}
	}
	
	/**
	 * Get the number of floors in the hotel
	 * @return number of floors in hotel
	 */
	public int getNumFloors() {
		return rooms.length;
	}
	
	/**
	 * Get the Room object given the foor and room number
	 * @param floor floor number
	 * @param room room number
	 * @return the Room object, or null if not exist
	 */
	public Room getRoom(int floor, int room) {
		if (floor > 0 && floor <= getNumFloors() && room > 0 && room <= rooms[floor-1].length) {
			return rooms[floor-1][room-1];
		}
		return null;
	}
	
	/**
	 * Find a list of rooms of a particular type and availability
	 * @param available whether to search for available or occupied rooms
	 * @param roomType type of room to be searched
	 * @return the list of matched rooms
	 */
	public List<Room> findRoomsByAvailability(boolean available, int roomType) {
		List<Room> result = new ArrayList<Room>();
		
		for (int i = 0; i < rooms.length; ++i) {
			for (int j = 0; j < rooms[i].length; ++j) {
				if (rooms[i][j].getType() == roomType && rooms[i][j].isOccupied() != available) {
					result.add(rooms[i][j]);
				}
			}
		}

		return result;
	}
	
	/**
	 * Find a list of rooms based on availability
	 * @param available whether to search for available or occupied rooms
	 * @return the list of matched rooms
	 */
	public List<Room> findRoomsByAvailability(boolean available) {
		List<Room> result = new ArrayList<Room>();
		
		for (int i = 0; i < rooms.length; ++i) {
			for (int j = 0; j < rooms[i].length; ++j) {
				if (rooms[i][j].isOccupied() != available) {
						result.add(rooms[i][j]);
				}
			}
		}

		return result;
	}
	
	/**
	 * Find rooms by searching occupants' name or member ID
	 * @param criteria either CRITERIA_NAME (search by name), CRITERIA_MEMBER_ID (search by member ID)
	 * @param query what to search
	 * @return the list of matched rooms
	 */
	public List<Room> findRoomsByOccupant(int criteria, final String query) {
		List<Room> result = new ArrayList<Room>();
		HotelUtil.Predicate<Occupant> pred;
		
		switch (criteria) {
		case CRITERIA_NAME:
			pred = new HotelUtil.Predicate<Occupant>() {
				@Override
				public boolean apply(Occupant val) {
					return val.getName().equals(query);
				}
			};
			break;
		case CRITERIA_MEMBER_ID:
			pred = new HotelUtil.Predicate<Occupant>() {
				@Override
				public boolean apply(Occupant val) {
					return val.getID().equals(query);
				}
			};
			break;
		default:
			return null;
		}

		for (int i = 0; i < rooms.length; ++i) {
			for (int j = 0; j < rooms[i].length; ++j) {
				if (rooms[i][j].isOccupied()) {
					if (pred.apply(rooms[i][j].getOccupant())) {
						result.add(rooms[i][j]);
					}
				}
			}
		}

		return result;
	}
	
	/**
	 * Check in a customer
	 * @param occupant customer to be checked in
	 * @param netAddr ethernet address used by the room; null if not used
	 * @throws InvalidActionException thrown when cannot check in the room
	 */
	protected void checkIn(Room room, Occupant occupant, String netAddr) throws InvalidActionException {
		if (room == null) {
			throw new InvalidActionException(HotelUtil.MSG_INVALID_ROOM);			
		} else if (room.isOccupied()) {		
			throw new InvalidActionException(HotelUtil.MSG_ROOM_EMPTY);
		} else if (!HotelUtil.isValidMemberID(occupant.getID())) {
			throw new InvalidActionException(HotelUtil.MSG_INVALID_FORMAT);
		}

		if (occupant.getType() == Occupant.BUSINESS && netAddr != null) {
			if (!HotelUtil.isValidEthernetAddress(netAddr)) {
				throw new InvalidActionException(HotelUtil.MSG_INVALID_FORMAT);
			}
			room.setDataService(netAddr);
		}
		
		room.setCheckInDate(getCurrentDate());
		room.setOccupant(occupant);
	}
	
	/**
	 * Check in a standard customer
	 * @param room Room to check in
	 * @param name name of customer
	 * @param id id of customer
	 * @throws InvalidActionException thrown when cannot check in the room
	 */
	public void checkIn(Room room, String name, String id) throws InvalidActionException {	
		Occupant occupant = new Occupant(name, id);
		checkIn(room, occupant, null);
	}
	
	/**
	 * Check in a business customer
	 * @param room Room to check in
	 * @param name name of customer
	 * @param id id of customer
	 * @param company company of customer
	 * @param netAddr ethernet address used by the room; null if not used
	 * @throws InvalidActionException thrown when cannot check in the room
	 */
	public void checkIn(Room room, String name, String id, String company, String netAddr) throws InvalidActionException {		
		Occupant occupant = new Occupant(name, id, company);
		checkIn(room, occupant, netAddr);
	}
	
	/**
	 * Check out a room
	 * @param room Room to check out
	 * @throws InvalidActionException thrown if cannot check out the given room
	 */
	public void checkOut(Room room) throws InvalidActionException {
		if (room == null) {
			throw new InvalidActionException(HotelUtil.MSG_INVALID_ROOM);			
		} else if (!room.isOccupied()) {		
			throw new InvalidActionException(HotelUtil.MSG_ROOM_EMPTY);
		} else if (room.getCheckInDate().compareTo(currentDate) > 0) {
			throw new InvalidActionException(HotelUtil.MSG_INVALID_DATE);
		}
		
		room.setOccupant(null);
		room.setDataService(null);
		room.setCheckInDate(null);
	}

	/**
	 * Get the date format used by the system 
	 * @return the system date format
	 */
	public DateFormat getDateFormat() {
		return dateFormatter;
	}

	/**
	 * Get current date
	 * @return current date
	 */
	public Date getCurrentDate() {
		return currentDate;
	}

	/**
	 * Increment the current date
	 * @param days number of days to increment
	 */
	public void incrementDate(int days) {		
		Calendar cal = Calendar.getInstance();
	    cal.setTime(currentDate);
	    cal.add(Calendar.DATE, days);
	    currentDate = cal.getTime();
	}

	/**
	 * Get the current date string
	 * @return current date, formatted with system date format
	 */
	public String getCurrentDateString() {
		return getDateFormat().format(getCurrentDate());
	}
}
