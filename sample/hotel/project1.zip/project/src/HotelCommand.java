import hkust.comp201.hw.HotelConfig;

import java.text.DateFormat;
import java.util.*;

/**
 * A command in the hotel system menu
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public abstract class HotelCommand {
    private String name;	//name of commands

    /**
     * Array of available commands
     */
	public static final HotelCommand[] COMMANDS = new HotelCommand[] {
		new ListOccupiedRoomsCommand(),
		new ListAvailableRoomsCommand(),
		new CheckAvailableRoomsCommand(),
		new CheckInCommand(),
		new CheckOutCommand(),
		new FindOccupantCommand(),
		new PrintRoomCommand(),
		new IncrementDateCommand(),
		new QuitCommand()
	};
	
	/**
	 * Command for listing all occupied rooms
	 */
	public static class ListOccupiedRoomsCommand extends HotelCommand {
		public ListOccupiedRoomsCommand() {
			super("List all occupied rooms");
		}
		
        @Override 
        public void execute() {
        	List<Room> matches = Hotel.getInstance().getModel().findRoomsByAvailability(false);
        	System.out.printf("Number of matches: %d\n", matches.size());
        	
        	for (Iterator<Room> iter = matches.iterator(); iter.hasNext();) {
        		HotelUtil.printRoomDetails(iter.next());
        	}
        }	    
	}
	
	/**
	 * Command for listing all available rooms
	 */
	public static class ListAvailableRoomsCommand extends HotelCommand {
		public ListAvailableRoomsCommand() {
			super("List all available rooms");
		}
		
        @Override 
        public void execute() {
        	List<Room> matches = Hotel.getInstance().getModel().findRoomsByAvailability(true);
        	System.out.printf("Number of matches: %d\n", matches.size());
        	
        	for (Iterator<Room> iter = matches.iterator(); iter.hasNext();) {
        		HotelUtil.printRoomDetails(iter.next());
        	}
        }
    }
	
	/**
	 * Command for checking available rooms
	 */
	public static class CheckAvailableRoomsCommand extends HotelCommand {
		private Scanner in = new Scanner(System.in);
		
		public CheckAvailableRoomsCommand() {
			super("Check availability for particular room type");
		}		    	
	    	
    	@Override 
        public void execute() {
    		int type = 0;
        	System.out.print("Which type of room to check? Standard [1], Executive [2], Presidential [3]: ");
        	try {
        		type = in.nextInt();				
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
			}		        	
        	
        	if (type < 1 || type > 3) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
        	}
        	
        	List<Room> matches = Hotel.getInstance().getModel().findRoomsByAvailability(true, type);
        	System.out.printf("Number of matches: %d\n", matches.size());
        	
        	for (Iterator<Room> iter = matches.iterator(); iter.hasNext();) {
        		HotelUtil.printRoomDetails(iter.next());
        	}	
        }
	}
	
	/**
	 * Command for checking in
	 */
	public static class CheckInCommand extends HotelCommand {
		private Scanner in = new Scanner(System.in);
		public CheckInCommand() {
			super("Check in");			
		}
		    			    	
    	@Override 
        public void execute() {
    		Hotel hotel = Hotel.getInstance();
    		int floorNo = 0, roomNo = 0, type = 0;
    		String name = "", id = "", company = "", netAddr = null;
    		
    		System.out.println("Which room to check in?");
    		try {
        		System.out.print("Floor: ");
				floorNo = in.nextInt();
				System.out.print("Room Number: ");
				roomNo = in.nextInt();
				in.nextLine();
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_FORMAT);
				return;
			}

    		Room room = hotel.getModel().getRoom(floorNo, roomNo);
    		if (room == null) {
				System.out.println(HotelUtil.MSG_INVALID_ROOM);
				return;		        		
        	} else if (room.isOccupied()) {
				System.out.println(HotelUtil.MSG_ROOM_OCCUPIED);
				return;				        		
        	}
    		
    		System.out.println("Check in the room:");
    		HotelUtil.printRoomDetails(room);
    		
    		System.out.print("Yes [Y], No [N]: ");
    		String confirm = in.nextLine();
    		
    		if (confirm.equals("Y") || confirm.equals("y")) {
    			// Proceed
    		} else if (confirm.equals("N") || confirm.equals("n")) {
    			return;
    		} else {
    			System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
    		}
    		
    		System.out.println("Input occupant's information:");
    		System.out.print("Name: ");
    		name = in.nextLine();
    		
	    	do {
	    		System.out.print("Member ID: ");
	    		id = in.nextLine();
	    		if (!HotelUtil.isValidMemberID(id)) {
	    			System.out.println(HotelUtil.MSG_INVALID_FORMAT);
					continue;
	    		}
	    		break;			    		
    		} while (true);
	    	
    		System.out.print("Type (Standard [1], Business [2]): ");
    		try {
        		type = in.nextInt();
        		in.nextLine();
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
			}	
    		if (type != Occupant.STANDARD && type != Occupant.BUSINESS) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;		    			
    		}
    				    		
    		if (type == Occupant.BUSINESS) {
    			System.out.print("What is the name of the company occupant working for: ");
	    		company = in.nextLine();
	    		
    			if (room.getType() == HotelConfig.STANDARD_ROOM) {
    				System.out.printf("Warning: Data service is not available in room %s\n", room.getRoomNo());
    			} else {
    				System.out.print("Is data service required? Yes [Y], No [N]: ");
    				confirm = in.nextLine();
		    		
		    		if (confirm.equals("Y") || confirm.equals("y")) {
		    			do {
		    				System.out.print("What is the ethernet address: ");
		    				netAddr = in.nextLine();
		    				if (HotelUtil.isValidEthernetAddress(netAddr)) {
		    					break;
		    				} else {
		    					System.out.println(HotelUtil.MSG_INVALID_FORMAT);
		    				}
		    			} while (true);
		    		} else if (confirm.equals("N") || confirm.equals("n")) {
		    			// Proceed
		    		} else {
		    			System.out.println(HotelUtil.MSG_INVALID_SELECTION);
						return;
		    		}				    		
    			}
    		}	
    		
    		try {
    			if (type == Occupant.BUSINESS) {    			
					hotel.getModel().checkIn(room, name, id, company, netAddr);					
	    		} else {
	    			hotel.getModel().checkIn(room, name, id);
	    		}
    		} catch (HotelModel.InvalidActionException ex) {
    			System.out.println(ex.getMessage());
    			return;
			}
    		
    		System.out.println("Done.");
        }
    }
	
	/**
	 * Command for checking out
	 */
	public static class CheckOutCommand extends HotelCommand {
		private Scanner in = new Scanner(System.in);	    
		
		public CheckOutCommand() {
			super("Check out");
		}	
    	
    	@Override 
        public void execute() {	
    		Hotel hotel = Hotel.getInstance();
    		HotelModel hotelModel = hotel.getModel();
    		int floorNo = 0, roomNo = 0;
    		System.out.println("Which room to check out?");
    		try {
        		System.out.print("Floor: ");
				floorNo = in.nextInt();
				System.out.print("Room Number: ");
				roomNo = in.nextInt();
				in.nextLine();
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_FORMAT);
				return;
			}

    		Room room = hotelModel.getRoom(floorNo, roomNo);
    		if (room == null) {
				System.out.println(HotelUtil.MSG_INVALID_ROOM);
				return;		        		
        	} else if (!room.isOccupied()) {
				System.out.println(HotelUtil.MSG_ROOM_EMPTY);
				return;				        		
        	}

    		System.out.printf("Check out occupant: %s Yes [Y], No [N]: ", room.getOccupant().toString());
    		String confirm = in.nextLine();
    		
    		if (confirm.equals("Y") || confirm.equals("y")) {
    			// Proceed
    		} else if (confirm.equals("N") || confirm.equals("n")) {
    			return;
    		} else {
    			System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
    		}
    		
    		double rate = room.getRate();
    		Date from = room.getCheckInDate(), to = hotel.getModel().getCurrentDate();
    		DateFormat formatter = hotel.getModel().getDateFormat();
    		long numDays = HotelUtil.daysDiff(from, to);

    		try {
    			hotelModel.checkOut(room);
    		} catch (HotelModel.InvalidActionException ex) {
    			System.out.println(ex.getMessage());
    			return;
    		}
    		
    		System.out.printf("Room rate: %.1f\n", rate);
    		System.out.printf("Date of checking in: %s\n", formatter.format(from));
    		System.out.printf("Date of checking out: %s\n", formatter.format(to));
    		System.out.printf("Number of days stayed: %d\n", numDays);
    		System.out.printf("Bill: %.1f\n", rate * numDays);
    		System.out.println("Done.");
        }
    }
	
	/**
	 * Command for searching occupants
	 */
	public static class FindOccupantCommand extends HotelCommand {
		private Scanner in = new Scanner(System.in);
		
		public FindOccupantCommand() {
		    super("Find an occupant");
		}   	
    	
    	@Override 
        public void execute() {
        	int criteria = 0;
        	String query = "";
        	HotelModel hotel = Hotel.getInstance().getModel();
        	System.out.print("What is the searching field? Name [1], Member ID [2]: ");
        			        		        	
			try {
				criteria = in.nextInt();	
				in.nextLine();
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
			}		   
			
			if (criteria != 1 && criteria != 2) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
			}

        	switch (criteria) {
        	case HotelModel.CRITERIA_NAME:
        		System.out.print("Occupant's name: ");
        		query = in.nextLine();
        		break;
        	case HotelModel.CRITERIA_MEMBER_ID:
        		do {
        			System.out.print("Member ID: ");
        			query = in.nextLine();
        			
        			if (!HotelUtil.isValidMemberID(query)) {
        				System.out.println(HotelUtil.MSG_INVALID_FORMAT);
        				continue;
        			}
        			break;		        			
        		} while (true);		        		
        		break;
        	}
			
        	List<Room> matches = hotel.findRoomsByOccupant(criteria, query);
        	System.out.printf("Number of matches: %d\n", matches.size());
        	
        	for (Iterator<Room> iter = matches.iterator(); iter.hasNext();) {
        		HotelUtil.printRoomDetails(iter.next());
        	}
        }
    }
	
	/**
	 * Command for printing room content
	 */
	public static class PrintRoomCommand extends HotelCommand {    
    	private Scanner in = new Scanner(System.in);
    	
    	public PrintRoomCommand() {
    		super("Print room content");    		
    	}
    	
    	@Override 
        public void execute() {
        	int floorNo = 0, roomNo = 0;
        	System.out.println("Which room to print?");	        	
        	try {
        		System.out.print("Floor: ");
				floorNo = in.nextInt();
				System.out.print("Room Number: ");
				roomNo = in.nextInt();
				in.nextLine();
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_FORMAT);
				return;
			}		        	
        	
        	Room room = Hotel.getInstance().getModel().getRoom(floorNo, roomNo);
        	if (room == null) {
				System.out.println(HotelUtil.MSG_INVALID_ROOM);
				return;		        		
        	}
        	
        	HotelUtil.printRoomDetails(room);
        }
    }
	
	/**
	 * Command for incrementing current date
	 */
	public static class IncrementDateCommand extends HotelCommand {
		private Scanner in = new Scanner(System.in);
	
		public IncrementDateCommand() {
			super("Increment date");
		}    	
    	
        @Override 
        public void execute() {
        	Hotel hotel = Hotel.getInstance();
        	System.out.printf("Current date is: %s\n", hotel.getModel().getCurrentDateString());
        	System.out.print("Number of day(s) to increase: ");
        		
        	int days = 0;
			try {
				days = in.nextInt();			        	   
			} catch (InputMismatchException e) {
				System.out.println(HotelUtil.MSG_INVALID_SELECTION);
				return;
			}		   
			
			hotel.getModel().incrementDate(days);
        	System.out.printf("Today is: %s\n", hotel.getModel().getCurrentDateString());	  
        }
    }
	
	/**
	 * Command for quiting the system
	 */
	public static class QuitCommand extends HotelCommand {
    	public QuitCommand() {
    		super("Quit");
    	}
    	
        @Override 
        public void execute() {
        	Hotel.getInstance().quit();
        	System.out.println("Thanks for using Hotel Room Management System.");
        }
    }

	/**
	 * Construct a hotel system menu/command option
	 * @param name name of the menu option
	 */
    public HotelCommand(String name) {
        this.name = name;
    }

    /**
     * Get the name of this command option
     */
    @Override 
    public String toString() {
        return name;
    }

    /**
     * Execute the command
     */
    public abstract void execute();
}
