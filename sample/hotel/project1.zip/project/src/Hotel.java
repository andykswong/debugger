import java.util.InputMismatchException;
import java.util.Scanner;

import hkust.comp201.hw.HotelConfig;
import hkust.comp201.hw.HotelConfigException;

/**
 * Entry class for the hotel management system
 * @author Wong Kwok Shiu 
 * @author kswongab@ust.hk
 * @author Student ID: 20018297
 */
public class Hotel {	
	private boolean pendingQuit = false;
	
	private HotelConfig config;
	private HotelModel model;	
	
	private static Hotel hotelInstance;
	
	/**
	 * Main entry function
	 */
	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("Hotel configuration XML file not specified!");
			return;
		}
		
		HotelConfig config;
		try {
			config = new HotelConfig(args[0]);
		} catch (HotelConfigException e) {
			System.out.println("Invalid hotel configuration XML file!");
			return;
		}

		hotelInstance = new Hotel(config);
		hotelInstance.run();
	}
	
	/**
	 * Get an instance of the Hotel class
	 * @return the singleton Hotel instance
	 */
	public static Hotel getInstance() {
		return hotelInstance;
	}
	
	/**
	 * Constructor, protected for singleton pattern
	 * @param config hotel config
	 */
	protected Hotel(HotelConfig config) {
		this.config = config;
		model = new HotelModel(config);
	}
	
	/**
	 * Quit the hotel system, if it is running
	 */
	public void quit() {
		pendingQuit = true;
	}
	
	/**
	 * Run the hotel management system
	 */
	public void run() {
		int choice = -1;
		Scanner in = new Scanner(System.in);

		printWelcomeMessage();
		
		while (!pendingQuit) {
			printMenu();
			System.out.print("Choice: ");
			
			try {
				choice = in.nextInt();
			} catch (InputMismatchException e) {
				choice = 0;
			}
			in.nextLine();
			
			if (choice > 0 && choice <= HotelCommand.COMMANDS.length) {
				HotelCommand.COMMANDS[choice-1].execute();
			} else {
				System.out.println("Invalid selection!");
			}	
			
		    System.out.println("Press \"Enter\" key to continue...");
	    	in.nextLine();
		}
		
		in.close();
	}
	
	/**
	 * Get the hotel model
	 * @return the hotel model
	 */
	public HotelModel getModel() {
		return model;
	}
	
	/**
	 * Print the welcome message
	 */
	public void printWelcomeMessage() {
		System.out.println("***********Hotel Room Management System************");
		System.out.printf("Welcome to \"%s\" hotel.\n", config.getName());
		System.out.printf("Today is: %s\n", model.getCurrentDateString());
		System.out.println("***************************************************");
	}
	
	/**
	 * Print the menu for hotel management
	 */
	public void printMenu() {
		System.out.println("Select desired operation:");
		for (int i = 1; i <= HotelCommand.COMMANDS.length; ++i) {
		    System.out.printf("%s [%d]\n", HotelCommand.COMMANDS[i-1], i);
		}
	}
}
