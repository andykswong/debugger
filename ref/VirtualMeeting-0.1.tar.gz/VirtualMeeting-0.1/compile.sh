#! /bin/bash

# This script assumes that a compatible JDK 1.4 environnement
# is set.
# The environnement variable JDK_HOME must be set and refer to
# the install dir of the JDK 1.4 directory.
# The environnement variable CLASSPATH must target the JDK 1.4
# standard API.

# This script will compile Virtual Meeting system and trace tools.

# Compile all :

echo "Compiling, this may take a while..."

javac -g -classpath $CLASSPATH:src:$JDK_HOME/lib/tools.jar -d bin src/MtgServer/*.java src/Tracer/*.java src/Testing/*.java

echo "done"
