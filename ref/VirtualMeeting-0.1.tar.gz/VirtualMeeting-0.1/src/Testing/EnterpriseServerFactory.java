/*
 * EnterpriseServerFactory.java
 *
 * Created on 10 juillet 2002, 20:22
 */

package Testing;

import MtgServer.*;

/**
 * Concrete factory the create an Enterprise server :
 * All meetings are available (no limitation), languages = all, default language = english
 */
public class EnterpriseServerFactory extends ServerFactory {
    
    
    /** Builds or not the translator for the server.
     */
    public void makeTranslator() {
        server.setTranslator(new Translator());
    }
    
    /** Set the set of available meetings to the server to be build.
     */
    public void makeAvailablemeetings() {
        AvailableMeetings mtgs = new AvailableMeetings();
        mtgs.addMeeting("private", new PrivateMtg());
        mtgs.addMeeting("democratic", new DemocraticMtg());
        mtgs.addMeeting("standard", new StandardMtg());
        server.setAvailableMtgs(mtgs);
    }
    
    /** Initialize the ServerMessage singleton with available languages.
     */
    public void makeLanguages() {
        ServerMessages sms = ServerMessages.getInstance();
        sms.addLanguage(new EnglishMsg());
        sms.addLanguage(new FrenchMsg());
        sms.addLanguage(new SpanishMsg());
        sms.setDefaultLanguage(languages.English);
        server.addCommand("CHOOSELANGUAGE", new ChooseLanguage());
    }
    
}
