/*
 * DemoServerFactory.java
 *
 * Created on 10 juillet 2002, 20:15
 */

package Testing;

import MtgServer.*;

/**
 * Concrete factory the create a Demo server :
 * Only Standard limeted meeting is available, No multilanguage, default language = english
 */
public class DemoServerFactory extends ServerFactory {
    
  /** Builds or not the translator for the server.
     */
    public void makeTranslator() {
        // no translator in this version
    }
    
    /** Set the set of available meetings to the server to be build.
     */
    public void makeAvailablemeetings() {
        // only standard limited meetings ( 5 users maxi )
        AvailableMeetings mtgs = new AvailableMeetings();
        mtgs.addMeeting("standard", new LimitedMeeting(5, new StandardMtg()));
        server.setAvailableMtgs(mtgs);
    }
    
    /** Initialize the ServerMessage singleton with available languages.
     */
    public void makeLanguages() {
        // only english
        ServerMessages sms = ServerMessages.getInstance();
        sms.addLanguage(new EnglishMsg());
        sms.setDefaultLanguage(languages.English);
    }
    
}
