package Testing;

import MtgServer.*;

/** Use of the pattern Abstract Factory to build the server which matchs with
 * required parameters
 */
public abstract class ServerFactory 
{

    /** The server to be build
     */    
    protected MtgServer.Server server;

    /** Get the builded serve. this method should be called after calling every others
     * to get a full configured server
     * @return the builded server
     */    
    public MtgServer.Server getServer (DummyInterface inter) {
        server = new DummyServer(inter);
        server.createCommonCommands();
        makeAvailablemeetings();
        makeTranslator();
        makeLanguages();
        return this.server;
    }

    /** Set the set of available meetings to the server to be build.
     */    
    public abstract void makeAvailablemeetings();

    /** Builds or not the translator for the server.
     */    
    public abstract void makeTranslator();


    /** Initialize the ServerMessage singleton with available languages.
     */    
    public abstract void makeLanguages();

    /** Initialize the server factory and the common features of the server.
     */    
    public void ServerFactory()
    {
      
    }
}
