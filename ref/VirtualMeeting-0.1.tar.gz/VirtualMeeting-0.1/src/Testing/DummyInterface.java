/*
 * SimpleInterface.java
 *
 * Created on 15 juillet 2002, 20:48
 */

package Testing;

import MtgServer.*;

/**
 *
 * @author  franck
 */
public class DummyInterface {
    
    protected java.io.BufferedReader input;
    
    protected java.io.BufferedWriter output;
    
    
    /** Creates a new instance of SimpleInterface */
    public DummyInterface(java.io.Reader r, java.io.Writer w) 
    {
        input = new java.io.BufferedReader(r);
        output = new java.io.BufferedWriter(w);
    }
    
    /** Getter for property input.
     * @return Value of property input.
     */
    public java.io.BufferedReader getInput() {
        return input;
    }
    
    /** Setter for property input.
     * @param input New value of property input.
     */
    public void setInput(java.io.BufferedReader input) {
        this.input = input;
    }
    
    /** Getter for property output.
     * @return Value of property output.
     */
    public java.io.BufferedWriter getOutput() {
        return output;
    }
    
    /** Setter for property output.
     * @param output New value of property output.
     */
    public void setOutput(java.io.BufferedWriter output) {
        this.output = output;
    }
    
    public String getNextCommand() {
        try {
            return input.readLine();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    
    public void sendMessage(String msg) {
        try {
            output.write(msg);
            output.newLine();
            output.flush();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
