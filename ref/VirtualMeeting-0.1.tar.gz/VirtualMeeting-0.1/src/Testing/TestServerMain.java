package Testing;

import java.io.*;
import MtgServer.*;
/**
 *
 * @author  franck
 */
public class TestServerMain {
    
    /** Creates a new instance of ConsoleTestMain */
    public TestServerMain() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // input and output of the server
        Reader in = null;
        Writer out = null;
        String product;
        ServerFactory factory = null;
        
        // check no arguments error
        if (args.length == 0) printUsage();
        
        // check help :
        if (args[0].equals("-help")) printUsage();
        
        // get the product :
        product = args[0];
        
        // try to find the corresponding factory
        if (product.equals("Demo")) factory = new DemoServerFactory();
        else if (product.equals("Personal")) factory = new PersonalServerFactory();
        else if (product.equals("Enterprise")) factory = new EnterpriseServerFactory();
        else {
            System.err.println("ERROR : Requested product: "+product+" not found");
            printUsage();
        }
        
        // is there an input file ?
        if (args.length > 1) {
            File inf = new File(args[1]);
            if (!inf.exists() || !inf.isFile() || !inf.canRead()) {
                System.err.println("ERROR : Input file not found or not readable : " + args[1]);
                System.exit(-1);
            }
            try {
                in = new FileReader(inf);
            }
            catch (Exception e) {
                System.err.println("ERROR : Unable to read input file : " + args[1]);
                System.exit(-1);
            }
        }
        
        // is there an output file ?
        if (args.length > 2) {
            File outf = new File(args[2]);
            
            if (outf.exists()) {
                System.err.println("WARNING : Output file exists, overwritting : " + args[2]);
                if (!outf.delete()) {
                    System.err.println("ERROR : Unable to overwrite output file");
                    System.exit(-1); 
                }
            }
            
            try {
                outf.createNewFile();
            } 
            catch (Exception e) {
                System.err.println("ERROR : Unable to create output file");
                System.exit(-1); 
            }
            
            if (!outf.exists() || !outf.isFile() || !outf.canWrite()) {
                System.err.println("ERROR : Unable to create output file : " + args[2]);
                System.exit(-1);
            }
            
            try {
                out = new FileWriter(outf);
            } 
            catch (Exception e) {
                System.err.println("ERROR : Unable to create output file");
                System.exit(-1); 
            }
        }
        
        // set default I/O settings :
        if (in == null) in = new InputStreamReader(System.in);
        if (out == null) out = new OutputStreamWriter(System.out);
 
        // build an The server dummy interface on in and out
        DummyInterface inter = new DummyInterface(in, out);
        
        // build and launch the server
        Server server =  factory.getServer(inter);
        // give a name to the server thread
        server.setName("ServerThread");
        // Start the server
        server.start();
    }
    
    public static void printUsage() {
        System.err.println("Virtual Meeting Product Line Test Utility : ");
        System.err.println("--------------------------------------------");
        System.err.println("USAGE : java TestServerMain [Product] <opt_in_file> <opt_out_file>");
        System.err.println("   * Product : The product to launch ( Demo | Personal | Enterprise)");
        System.err.println("   * opt_in_file  : optional input file containing server commands");
        System.err.println("   * opt_out_file : optional file to store server output");
        System.err.println();
        System.err.println("REMARK 1 : if you are using input files, the last command in the input");
        System.err.println("           file should be EXIT to stop the server.");
        System.err.println("REMARK 2 : with no optionals arguments the server commands are read from");
        System.err.println("           the standard input and outputs are written on the standard output.");
        System.err.println();
        System.exit(-1);
    }
    
}
