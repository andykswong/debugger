/*
 * DummyServer.java
 *
 * Created on 16 juillet 2002, 02:22
 */

package Testing;

import MtgServer.*;
/**
 *
 * @author  franck
 */
public class DummyServer extends Server {
    
    private DummyInterface dummyInterface;
    
    /** Creates a new instance of DummyServer */
    public DummyServer(DummyInterface interface_i) {
        dummyInterface = interface_i;
    }
    
    /** send a message to a user
     * @param user_channel the channel of the user
     * @param message_i the message to send
     */
    public void send(String user_channel, MtgServer.Message message_i) {
        dummyInterface.sendMessage(user_channel +"| " + message_i.getSender() + " -> " + message_i.getText());
    }
    
    public void run() {
        
        String cmd;
        dummyInterface.sendMessage("Virtual meeting server starting...");
        dummyInterface.sendMessage(" -> EXIT to quit server.");
        dummyInterface.sendMessage(" -> DUMP to view server internal state.");
        dummyInterface.sendMessage("Server is ready !");
        while(true) {
            cmd = dummyInterface.getNextCommand();
            if (cmd.equals("EXIT")) break;
            else if (cmd.equals("DUMP")) dummyInterface.sendMessage(dump());
            else if (cmd.trim().equals("")) continue;
            else if (cmd.trim().charAt(0) == '#') dummyInterface.sendMessage("COMMENT : " + cmd.trim().substring(1));
            else exec(cmd);
        }
    }
    
}
