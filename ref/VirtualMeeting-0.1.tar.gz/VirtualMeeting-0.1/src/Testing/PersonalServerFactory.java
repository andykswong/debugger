/*
 * PersonalServerFactory.java
 *
 * Created on 10 juillet 2002, 20:20
 */

package Testing;

import MtgServer.*;
/**
 *Concrete factory the create a Personal server :
 * All limeted meeting are available, languages = fr/eng, default language = english
 */
public class PersonalServerFactory extends ServerFactory {
    
     /** Builds or not the translator for the server.
     */
    public void makeTranslator() {
        // no translator
    }
    
    /** Set the set of available meetings to the server to be build.
     */
    public void makeAvailablemeetings() {
        // all meetings limited to 5 users
        AvailableMeetings mtgs = new AvailableMeetings();
        mtgs.addMeeting("private", new LimitedMeeting(5, new PrivateMtg()));
        mtgs.addMeeting("democratic", new LimitedMeeting(5,new DemocraticMtg()));
        mtgs.addMeeting("standard", new LimitedMeeting(5,new StandardMtg()));
        server.setAvailableMtgs(mtgs);
    }
    
    /** Initialize the ServerMessage singleton with available languages.
     */
    public void makeLanguages() {
        // Only English and french
        ServerMessages sms = ServerMessages.getInstance();
        sms.addLanguage(new EnglishMsg());
        sms.addLanguage(new FrenchMsg());
        sms.setDefaultLanguage(languages.English);
        server.addCommand("CHOOSELANGUAGE", new ChooseLanguage());
    }
    
}
