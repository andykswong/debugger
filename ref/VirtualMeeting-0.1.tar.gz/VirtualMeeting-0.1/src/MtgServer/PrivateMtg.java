package MtgServer;


public class PrivateMtg extends MtgServer.ModeratedMtg
{

    protected java.util.Hashtable authorized = new java.util.Hashtable();
    
    public MtgServer.User getAuthorized (String channel) {
        return (MtgServer.User)this.authorized.get(channel);
    }
    
    public java.util.Hashtable getAuthorized() {
        return authorized;
    }
    
    public void setAuthorized(User usr) {
        if (getAuthorized(usr.getChannel()) == null)
            authorized.put(usr.getChannel(), usr);
    }
    
    public int cardAuthorized () {
        return this.authorized.size();
    }

    public MeetingTypes getType() {
        return MeetingTypes.Private;
    }
    
    public void plan(String name, MtgServer.User user_i) throws NoMeetingTransitionException
    {
        super.plan(name, user_i);
        setAuthorized(user_i);
    }
    
    public void enter(User user_i, Server server_i) throws MeetingSecurityException, NoUserTransitionException
    {
        if (authorized.contains(user_i))
            super.enter(user_i, server_i);
        else
            throw new MeetingSecurityException();
    }
}
