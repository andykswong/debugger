package MtgServer;

public class SetAgenda extends MtgServer.SetCmd {
    
    public void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i) {
        
        // get the new Agenda
        String agenda = "";
        while(tokenizer_i.hasMoreTokens()) agenda += tokenizer_i.nextToken(" ") + " ";
        agenda = agenda.trim();
        mtg.setAgenda(agenda);
    }
    
}
