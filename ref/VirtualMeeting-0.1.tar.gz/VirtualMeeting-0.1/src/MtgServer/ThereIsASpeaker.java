package MtgServer;

/** State : There is curently a speaker in the meeting
 */
public class ThereIsASpeaker extends MeetingState
{

    /** get a new instance of the state from the user about to speak
     * @param speaker the user about to speak
     * @return the new instance of the state
     */    
    public static ThereIsASpeaker getInstance(User speaker) 
    {
        return new ThereIsASpeaker(speaker);
    }
    
    /** make the state from the user about to speak
     * @param speaker the user about to speak
     */    
    protected ThereIsASpeaker(User speaker) 
    {
        currentSpeaker = speaker;
    }
    
    /** the user speaking in the meeting
     */    
    protected MtgServer.User currentSpeaker;
    
    /** get the user who is speaking in the meeting
     * @return the user who is speaking in the meeting
     */    
    public MtgServer.User getCurrentSpeaker () {
        return this.currentSpeaker;
    }

    /** transition to openned state
     */    
    public void over(MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        try {
            currentSpeaker.over(meeting_i);
            meeting_i.setCurrentState(Opened.getInstance());
        } 
        catch(Exception e) { throw new NoMeetingTransitionException(); }
    }

    /** transition to closed state
     */    
    public void close(MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        try {
            // make the speaker stop
            meeting_i.getCurrentState().over(meeting_i);
            // close the meeting
            meeting_i.getCurrentState().close(meeting_i);
        } 
        catch(Exception e) { throw new NoMeetingTransitionException(); }
    }
    
     public void broadcast(MtgServer.ConcreteMeeting meeting_i, Server server_i, Message msg) throws MeetingSecurityException
    {
        // security check
        if (!msg.getSender().equals(currentSpeaker.getName()))
            throw new MeetingSecurityException();
        
        msg.setSender(meeting_i.getName()+":"+ msg.getSender());
        // broadcasts the message
        java.util.Hashtable usrs = meeting_i.getUsers();
        User dest;
        java.util.Iterator it = usrs.values().iterator();
        while(it.hasNext()) {
            dest = (User)it.next();
            dest.send(server_i,msg);
        }
    }
}
