package MtgServer;


public class Speaking extends MtgServer.UserState
{
    
     /** Implementation of the singleton pattern : only instance of the concrete user state
     */    
    protected static UserState singleton = null;
    
    /** Implementation of the singleton Design Pattern
     * @return the only instance of the concrete state
     */    
    public static UserState getInstance() {
        if (singleton == null) singleton = new Speaking();
        return singleton;
    }
    
    /** Implementation of the singleton Design Pattern
     */    
    protected Speaking() {}

    public void leave(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        try {
            meeting.over(user_i);
            user_i.setCurrentState(Registered.getInstance());
        }
        catch (Exception e) {
            throw new NoUserTransitionException();
        }
    }

    public void over(MtgServer.Meeting meeting, MtgServer.User user_i)
    {
        user_i.setCurrentState(InMeeting.getInstance());
    }
}
