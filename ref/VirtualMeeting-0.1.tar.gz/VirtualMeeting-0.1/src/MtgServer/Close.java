package MtgServer;

/** Command close : close an opened meeting 
 * Syntax of the Close command
 * <CODE>
 * CLOSE [meeting_name]
 * 
 * (Must be performed by the meeting moderator or owner)
 *
 * ex : OPEN secrete_meeting
 * </CODE>
 */
public class Close extends MtgServer.Command
{
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        User usr;
        // The user must be connected
        if ( (usr = checkUser(channel, server_i) ) == null ) return;
        
        // get the meeting name and the command
        String m_name;
        
        // get the meeting name :
        if (tokenizer_i.hasMoreTokens())
            m_name = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"OPEN [meeting_name]");
            return; 
        }
        
         // check the meeting :
        Meeting mtg = server_i.getMeeting(m_name);
        if (mtg == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidMeeting"));
            return;
        }
        
        // Security check (only Owner and moderator can perform "open" operations)
        if (mtg.getModerator() != usr && mtg.getOwner() != usr) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("NotAllowed"));
            return;
        }
        
        // try to open the meeting :
        try {
            mtg.close(usr);
        }
        catch (Exception e) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidOperation"));
        }
    }
    
}
