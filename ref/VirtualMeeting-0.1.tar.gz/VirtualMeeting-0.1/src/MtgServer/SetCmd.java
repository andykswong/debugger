package MtgServer;

abstract public class SetCmd 
{

    public abstract void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i);
    
    public void sendError(String channel, MtgServer.Server server_i, String msg) {
        // try to get the user
        User user = server_i.getUser(channel);
        // get the serverMessage singleton
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg lm;
        // choose language
        if (user == null) lm = sms.getTables(sms.getDefaultLanguage());
        else lm = sms.getTables(user.getLanguage());
        // send message
        server_i.send(channel, new MtgServer.Message(msg, lm.get("server")+":"+this.getClass().getName(), lm.getLanguage())); 
    }
        
}
