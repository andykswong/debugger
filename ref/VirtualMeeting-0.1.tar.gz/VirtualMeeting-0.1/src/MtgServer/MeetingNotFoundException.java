/*
 * MeetingNotFoundException.java
 *
 * Created on 11 juillet 2002, 00:49
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class MeetingNotFoundException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>MeetingNotFoundException</code> without detail message.
     */
    public MeetingNotFoundException() {
    }
    
    
    /**
     * Constructs an instance of <code>MeetingNotFoundException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public MeetingNotFoundException(String msg) {
        super(msg);
    }
}
