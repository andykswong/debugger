/*
 * English.java
 *
 * Created on 10 juillet 2002, 22:59
 */

package MtgServer;

/**
 *English set of messages
 */
public class EnglishMsg extends LanguageMsg {
    
    /** Creates a new instance of English, english is the default implementation 
     * language so there is nothing more to do here
     */
    public EnglishMsg() {
        super();
        this.language = languages.English;
        // no messages to add, because default messages are in english
        messages.put("unexpectedError","Unexpected error");
        messages.put("commandNotFound","Command not found");
        messages.put("incorrectArguments","Incorrect command arguments");
        messages.put("meetingNotFound","Meeting not found");
        messages.put("userNotFound","User not found");
        messages.put("server","server");
        messages.put("Server","Server");
        messages.put("alreadyConnected","You are already connected to this server server");
        messages.put("nameAlreadyUsed","The name you choose is already used to another user");
        messages.put("unableChangeMtgState","Unable to perform requested operation");
        messages.put("unableChangeUserState","Unable to perform requested operation");
        messages.put("MtgTypeNotAvailable","The type of meeting you requested is not available");
        messages.put("MtgNameAlreadyUsed","There is already a meeting with this name");
        messages.put("InvalidOperation","Unable to perform requested operation or you are not allowed to do so");
        messages.put("NotAllowed","You are not allowed to perform this operation");
        messages.put("InvalidMeeting","The requested meeting does not exist");
    }
    
}
