/*
 * DateFormatException.java
 *
 * Created on 13 juillet 2002, 00:46
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class DateFormatException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>DateFormatException</code> without detail message.
     */
    public DateFormatException() {
    }
    
    
    /**
     * Constructs an instance of <code>DateFormatException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public DateFormatException(String msg) {
        super(msg);
    }
}
