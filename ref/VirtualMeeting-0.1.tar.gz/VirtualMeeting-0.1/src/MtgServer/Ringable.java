package MtgServer;


// objecteering-startJavadoc....................................N/LNB/CU7EYL1:E8
// objecteering-endJavadoc......................................E/LNB/CU7EYL1:E8
public interface Ringable 
{
}
