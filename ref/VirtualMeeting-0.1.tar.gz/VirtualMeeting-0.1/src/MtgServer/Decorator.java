package MtgServer;
// objecteering-start..........................................T/FNO/0PELHP1:0A2
/**
  * default behaviors
  * The particular behaviors of the concrete decorators are impolemented in child classes, overriding methods.
  */
// objecteering-end............................................E/FNO/0PELHP1:0A2
public class Decorator implements MtgServer.Meeting, Cloneable
{
    
    protected Meeting component = null;
    
    /** Getter for property component.
     * @return Value of property component.
     */
    public MtgServer.Meeting getComponent() {
        return component;
    }
    
    /** Setter for property component.
     * @param component New value of property component.
     */
    public void setComponent(MtgServer.Meeting component) {
        this.component = component;
    }
    
    public Decorator(Meeting component_i) {
        component = component_i;
    }
   
    public void ask(User user_i, Server server_i) throws NoUserTransitionException, MeetingSecurityException {
        component.ask(user_i, server_i);
    }    
    
    public void broadcast(User user_i, MtgServer.Server server_i, MtgServer.Message message_i) throws MeetingSecurityException, NoUserTransitionException, NoMeetingTransitionException {
        component.broadcast(user_i, server_i, message_i); 
    }
    
    public void close(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException {
        component.close(user_i);
    }
    
    public void enter(User user_i, Server server_i) throws MeetingSecurityException, NoUserTransitionException {
        component.enter(user_i, server_i);
    }
    
    public String getAgenda() {
        return component.getAgenda();
    }
    
    public java.util.GregorianCalendar getDate() {
        return component.getDate();
    }
    
    public String getDuration() {
        return component.getDuration();
    }
    
    public User getModerator() {
        return component.getModerator();
    }
    
    public String getName() {
        return component.getName();
    }
    
    public User getOwner() {
        return component.getOwner();
    }
    
    public String getTitle() {
        return component.getTitle();
    }
    
    public MeetingTypes getType() {
        return component.getType();
    }
    
    public void handOver(MtgServer.User newSpeaker_i, MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException {
        component.handOver(newSpeaker_i, user_i);
    }
    
    public void leave(User user_i, Server server_i) throws NoUserTransitionException {
        //System.out.println("DEBUG : LEAVE -> DECORATOR");
        component.leave(user_i, server_i);
    }
    
    public void open(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException {
        component.open(user_i);
    }
    
    public void over(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException {
        component.over(user_i);
    }
    
    public void plan(String name, MtgServer.User user_i) throws NoMeetingTransitionException {
        component.plan(name, user_i);
    }
    
    public void setAgenda(String agenda_i) {
        component.setAgenda(agenda_i);
    }
    
    public void setDate(String date_i) {
        component.setDate(date_i);
    }
    
    public void setDuration(String duration_i) {
        component.setDuration(duration_i);
    }
    
    public void setModerator(User mod) {
        component.setModerator(mod);
    }
    
    public void setTitle(String title_i) {
        component.setTitle(title_i);
    }
    
    public Object clone() {
        try {
            Decorator deco = (Decorator)super.clone();
            deco.setComponent((Meeting)component.clone());
            return deco;
        }
        catch (Exception e) { e.printStackTrace(); }
        return null;
        
    }
    
    public String dump() {
        return component.dump();
    }
    
}
