package MtgServer;
/** Class representing a user connected to the server
 */
public class User 
{
    /** the name (or nickname) of the user
     */    
    protected String name;
   
    /** get the name of the user
     * @return the name of the user
     */    
    public String getName () {
        return this.name;
    }
    
    /** the channel of the user
     */
    protected String channel;
    
    /** Getter for property channel.
     * @return Value of property channel.
     */
    public java.lang.String getChannel() {
        return channel;
    }

    /** the state of the user (Steta desing pattern)
     */    
    protected MtgServer.UserState currentState;
    
    /** get the user state
     * @return the user state
     */    
    public MtgServer.UserState getCurrentState () {
        return this.currentState;
    }

    /** the user language
     */    
    protected MtgServer.languages language;
    
    /** get the user language
     * @return the user language
     */    
    public MtgServer.languages getLanguage () {
        return this.language;
    }

    /** the meeting the user is logged in or null if the user isn't currently in a meeting
     */    
    protected MtgServer.Meeting currentMeeting;
    
    /** get the user current meeting (null if the user isn't currently in a meeting)
     * @return the user current meeting
     */    
    public MtgServer.Meeting getCurrentMeeting () {
        return this.currentMeeting;
    }
    
    /** set the user current meeting
     * @param value the user current meeting
     */    
    public void setCurrentMeeting (MtgServer.Meeting value) {
        this.currentMeeting = value; 
    }
    
    /** make a new used
     * @param name_i name of the new user
     */    
    public User(String name_i, String channel_i)
    {
        name = name_i;
        channel = channel_i;
        language = ServerMessages.getInstance().getDefaultLanguage();
    }

    /** user enters a meeting
     * @param meeting the meeting to enter in
     */
    public void enter(MtgServer.Meeting meeting) throws NoUserTransitionException
    {
        currentState.enter(meeting, this);
    }

    /** the user leaves a meeting
     * @param meeting the meeting to leave
     */    
    public void leave(MtgServer.Meeting meeting) throws NoUserTransitionException
    {
        currentState.leave(meeting, this);
        currentMeeting = null;
    }

    /** try to enter the speaking state to allow user to speak
     * @param meeting the meeting to speak into
     */    
    public void handOver(MtgServer.Meeting meeting) throws NoUserTransitionException
    {
        currentState.handOver(meeting, this);
    }

    /** ask to speak in the current meeting
     * @param meeting the meeting to ask
     */    
    public void askPermission(MtgServer.Meeting meeting) throws NoUserTransitionException
    {
        currentState.askPermission(meeting, this);
    }

     /** the user speaking is over
     * @param meeting the meeting to ask
     */    
    public void over(MtgServer.Meeting meeting) throws NoUserTransitionException
    {
        currentState.over(meeting, this);
    }
    
    /** initialize the state
     */    
    public void connect()
    {
        setCurrentState(Registered.getInstance());
    }

    /** disconnect the user from server ?
     */    
    public void disconnect()
    {

    }

    /** change the language of the user
     * @param language_i the new language
     */    
    public void setLanguage(MtgServer.languages language_i)
    {
        this.language = language_i;
    }

    /** send a message to the user
     * @param server the server to use to send the message
     * @param message_i the message to send
     */    
    public void send(MtgServer.Server server, MtgServer.Message message_i)
    {
        // get the server translator
        Translator tsl = server.getTranslator();
        // translate message if needed
        if (tsl != null && message_i.getLanguage() != language) {
            tsl.translate(language, message_i);
        }
        // send the message
        server.send(channel, message_i);
    }
    
    /** Setter for property currentState.
     * @param currentState New value of property currentState.
     */
    public void setCurrentState(MtgServer.UserState currentState) {
        this.currentState = currentState;
    }
    
    public String dump() {
        String Result = "";
        Result += channel + " " + name + " " + language.toString() + " ";
        Result += currentState.getClass().getName();
        if (currentMeeting != null) Result += " " + currentMeeting.getName();
        return Result;
    }
}
