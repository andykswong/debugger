/*
 * MeetingSecurityException.java
 *
 * Created on 13 juillet 2002, 03:00
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class MeetingSecurityException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>MeetingSecurityException</code> without detail message.
     */
    public MeetingSecurityException() {
    }
    
    
    /**
     * Constructs an instance of <code>MeetingSecurityException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public MeetingSecurityException(String msg) {
        super(msg);
    }
}
