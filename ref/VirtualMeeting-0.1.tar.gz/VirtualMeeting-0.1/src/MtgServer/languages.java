package MtgServer;


// objecteering-startJavadoc....................................N/8KJ/0PELHP1:9I
// objecteering-endJavadoc......................................E/8KJ/0PELHP1:9I
public class languages implements java.io.Serializable
{
    private int value;
    private static final String[] strValues = {"English",
                                                                "French",
                                                                "Spanish"
                                                                };

    public static final languages English = new languages(0);
    public static final languages French = new languages(1);
    public static final languages Spanish = new languages(2);

    private static final languages[] enumValues = {English,
                                                                        French,
                                                                        Spanish
                                                                        };

    private languages(int code) {
        value = code;
    }

    public java.lang.String toString () {
        return strValues[value];
    }

    public int toInt () {
        return value;
    }

    public static languages fromString (String str) {
        languages toReturn = null;
        int i = 0;

        while (i < strValues.length)
        {
            if (strValues[i].equals(str))
                toReturn = enumValues[i];
            i++;
        }
        return toReturn;
    }

}
