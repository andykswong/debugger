package MtgServer;

public class GetModerator 
    extends MtgServer.GetCmd
{

    public void run(Server server_i, User usr, Meeting mtg) 
    {
        //get the moderator :
        User mod = mtg.getModerator();
        
        // is there a moderator ?
        if (mod == null) {
             sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("NoModerator"));
            return;
        }
        
        // send the message
        sendMsg(usr, server_i, mod.getName());
    }    

}
