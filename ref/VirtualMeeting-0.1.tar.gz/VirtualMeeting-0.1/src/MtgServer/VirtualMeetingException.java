/*
 * VirtualMeetingException.java
 *
 * Created on 11 juillet 2002, 00:47
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class VirtualMeetingException extends java.lang.Exception {
    
    /**
     * Creates a new instance of <code>VirtualMeetingException</code> without detail message.
     */
    public VirtualMeetingException() {
    }
    
    
    /**
     * Constructs an instance of <code>VirtualMeetingException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public VirtualMeetingException(String msg) {
        super(msg);
    }
}
