package MtgServer;

/** Meeting opened state
 */
public class Opened extends MtgServer.MeetingState
{

    /** Pattern sinleton implementation
     */    
    protected static Opened singleton = null;
    
    /** Pattern sinleton implementation
     * @return the instance of the state
     */    
    public static Opened getInstance() {
        if (singleton == null) singleton = new Opened();
        return singleton;
    }

    /** Pattern sinleton implementation
     */    
    protected Opened() {}
    
    /** transition to close state
     */    
    public void close(MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        
        java.util.Hashtable usrs = meeting_i.getUsers();
        java.util.Iterator it = usrs.values().iterator();
        User usr;
        try {
            // make all users leave the meeting
            while(it.hasNext()) {
                usr = (User)it.next();
                usr.leave(meeting_i);
            }
            // close the meeting
            meeting_i.setCurrentState(Closed.getInstance());
        }
        catch (Exception e) { throw new NoMeetingTransitionException(); }
    }


    /** transition to ThereIsASpeaker state
     */    
    public void handOver(MtgServer.User newSpeaker_i, MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        try {
            newSpeaker_i.handOver(meeting_i);
            meeting_i.setCurrentState(ThereIsASpeaker.getInstance(newSpeaker_i));
        }
        catch (Exception e) { throw new NoMeetingTransitionException(); }
        
    }

}
