package MtgServer;

/** Command create : Enter an existing meeting 
 * Syntax of the Enter command
 * <CODE>
 * ENTER [meeting_name]
 *
 * ex : ENTER secrete_meeting
 * </CODE>
 */
public class Enter extends MtgServer.Command
{

    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
         User usr = null;
         // The user must be connected
         if ( (usr = checkUser(channel, server_i) ) == null ) return;
         
         // The user must not be in a meeting :
         if (usr.getCurrentMeeting() != null) {
             sendError(channel, server_i, server_i.langByChannel(channel).get("LeaveMeetingFirst"));
             return;
         }
         
         // get the name of the requested meeting
         String name;
         if (tokenizer_i.hasMoreTokens())
            name = tokenizer_i.nextToken(" ");
         else {
            this.sendIncorrectArgs(channel,server_i,"ENTER [meeting_name]");
            return; 
         }
         
         // try to get the corresponding meeting object
         Meeting mtg = server_i.getMeeting(name);
         if (mtg == null) {
             sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidMeeting"));
             return;
         }
         
         //try to perform operation
         try {
            mtg.enter(usr, server_i);
         }
         catch (Exception e) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidOperation"));
         }
         
    }    

}
