package MtgServer;

/** Command create : creates a new meeting 
 * Syntax of the Create command
 * <CODE>
 * CREATE [meeting_type] [meeting_name]
 * meeting_type = {private | democratic | standard}
 * ex : CREATE private secrete_meeting
 * </CODE>
 */
public class Create 
    extends MtgServer.Command
{
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        User usr = null;
        // The user must be connected
        if ( (usr = checkUser(channel, server_i) ) == null ) return;
        
        // the user must be in the Registered state
        if (usr.getCurrentMeeting() != null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("inMeeting"));
            return;
        }
        
        // check parameters :
        String type, name;
        // get the type of meeting :
        if (tokenizer_i.hasMoreTokens())
            type = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"CREATE [meeting_type] [meeting_name]");
            return; 
        }
        // get the meeting name :
        if (tokenizer_i.hasMoreTokens())
            name = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"CREATE [meeting_type] [meeting_name]");
            return; 
        }
        // check for extra args :
        if (tokenizer_i.hasMoreTokens()) {
            this.sendIncorrectArgs(channel,server_i,"CREATE [meeting_type] [meeting_name]");
            return; 
        }
        
        // check if the given name already exists
        if (server_i.getMeeting(name) != null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("MtgNameAlreadyUsed"));
            return;
        }
        
        // create the meeting
        try {
            server_i.createAndAddMeeting(name, type, usr);   
        }
        catch( UnavailableException e ) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("MtgTypeNotAvailable"));
        }
        catch ( Exception e ) {
             sendError(channel, server_i, server_i.langByChannel(channel).get("unexpectedError"));
        }
    }
    
}
