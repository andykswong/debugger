package MtgServer;

/** DeadLock meeting state : the meeting is closed
 */
public class Closed extends MtgServer.MeetingState
{
    /** Implementation of singleton pattern
     */    
    protected static Closed singleton = null;
    
    /** Implementation of singleton pattern
     * @return The only instance of the closed state
     */    
    public static Closed getInstance() {
        if (singleton == null) singleton = new Closed();
        return singleton;
    }
    
    /** Implementation of singleton pattern
     */    
    protected Closed() {}
}
