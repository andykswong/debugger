package MtgServer;
/** Command set : set meeting's fields
 * Syntax of the SET command
 * <CODE>
 * SET [meeting_name] [FIELD] [new_value]
 * FIELD = {MODERATOR | ACCESSLIST | DATE | DURATION | TITLE | AGENDA}
 * ex : SET secrete_meeting AGENDA vampires and demons
 * ex : SET secrete_meeting ACCESSLIST buffy xander annya willow spike
 * ex : SET secrete_meeting MODERATOR buffy
 * </CODE>
 */
public class Set extends MtgServer.Command
{
    
    protected java.util.Hashtable commands = new java.util.Hashtable();
    
    public Set() {
        createCommands();
    }
    
    private void createCommands() {
        commands.put("MODERATOR", new SetModerator());
        commands.put("ACCESSLIST", new SetAccessList());
        commands.put("DATE", new SetDate());
        commands.put("DURATION", new SetDuration());
        commands.put("TITLE", new SetTitle());
        commands.put("AGENDA", new SetAgenda());
    }
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        User usr;
        // The user must be connected
        if ( (usr = checkUser(channel, server_i) ) == null ) return;
        
        // get the meeting name and the command
        String m_name, comm;
        
        // get the meeting name :
        if (tokenizer_i.hasMoreTokens())
            m_name = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"SET [meeting_name] [FIELD] [new_value]");
            return; 
        }
        
        //get the field to set
        if (tokenizer_i.hasMoreTokens())
            comm = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"SET [meeting_name] [FIELD] [new_value]");
            return; 
        }
        
        // check the meeting :
        Meeting mtg = server_i.getMeeting(m_name);
        if (mtg == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidMeeting"));
            return;
        }
        
        // Security check (only Owner and moderator can perform "set" operations)
        if (mtg.getModerator() != usr && mtg.getOwner() != usr) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("NotAllowed"));
            return;
        }
        
        // get the command
        SetCmd com = (SetCmd)commands.get(comm);
        if (com == null) {
            this.sendIncorrectArgs(channel,server_i,"SET [meeting_name] [FIELD] [new_value]");
            this.sendIncorrectArgs(channel,server_i,"FIELD = {MODERATOR | ACCESSLIST | DATE | DURATION | TITLE | AGENDA}");
            return;
        }
        
        // invoke the command
        com.run(server_i, mtg, usr, tokenizer_i);
    }
    
}
