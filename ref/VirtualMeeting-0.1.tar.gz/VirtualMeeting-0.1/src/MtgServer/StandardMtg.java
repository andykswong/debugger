package MtgServer;



public class StandardMtg extends MtgServer.ModeratedMtg
{
    
    public MeetingTypes getType() {
        return MeetingTypes.Standard;
    }
    
}
