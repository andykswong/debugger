/*
 * UnvailableException.java
 *
 * Created on 14 juillet 2002, 18:50
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class UnavailableException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>UnvailableException</code> without detail message.
     */
    public UnavailableException() {
    }
    
    
    /**
     * Constructs an instance of <code>UnvailableException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public UnavailableException(String msg) {
        super(msg);
    }
}
