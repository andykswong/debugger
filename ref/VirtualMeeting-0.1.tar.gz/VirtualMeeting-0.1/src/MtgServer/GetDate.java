package MtgServer;

public class GetDate 
    extends MtgServer.GetCmd
{

    public void run(Server server_i, User usr, Meeting mtg) 
    {
        //send the message
        sendMsg(usr, server_i, mtg.getDate().toString());
    }    

}
