package MtgServer;
/**
 * Class SeverMessage is a singleton that contains messages sends by
 * the system in all languages suported by server.
 * It also defined the default language of the system.
 */
public class ServerMessages 
{
    
    /** The only instance of the class
     */    
    protected static MtgServer.ServerMessages singleton;

    /** Contains all available languages
     */    
    protected java.util.Hashtable tables = new java.util.Hashtable();

    /** Retreve the set of message in the language given as parameter
     *
     * @param language_i The language
     * @return The set of message
     * @pre language_i != null
     */    
    public LanguageMsg getTables (languages language_i) {
        return (LanguageMsg)this.tables.get(language_i);
    }

    /** get the number of available languages
     * @return the number of available languages
     */    
    public int cardTables () {
        return this.tables.size();
    }

    /** Reference to the default language
     */    
    protected MtgServer.languages defaultLanguage;

    /** Get the default language of the server
     * @return the default language of the server
     */    
    public MtgServer.languages getDefaultLanguage () {
        return this.defaultLanguage;
    }

    /** Constructor of the class. It is protected because only one instace of the class
     * can exist, created by the static getInstance method.
     */    
    protected ServerMessages()
    {

    }

    /** 
     * Add a language message set for this product
     * Only called by the Server Factory
     */    
    public void addLanguage(MtgServer.LanguageMsg table)
    {
        tables.put(table.getLanguage() , table);
    }
    
    /**
     * Set the default language of the server
     * The Language object that corresponds to this language
     * must have already added using the addLanguage method
     * Only called by the Server Factory
     */
    public void setDefaultLanguage(languages language_i) {
        defaultLanguage = language_i;
    }

    /** Get the only instance of ServerMessage. Check if singleton exists,
     * if it does not creates it and then returns it.
     * @return the only instance of ServerMessage class
     */    
    public static MtgServer.ServerMessages getInstance()
    {
        //Create the singleton if it does not exists
        if (singleton == null) singleton = new ServerMessages();
        return singleton;
    }
}
