package MtgServer;

public class GetDuration extends MtgServer.GetCmd
{

    public void run(Server server_i, User usr, Meeting mtg) 
    {
        //send message
        sendMsg(usr, server_i, mtg.getDuration());
    }    

}
