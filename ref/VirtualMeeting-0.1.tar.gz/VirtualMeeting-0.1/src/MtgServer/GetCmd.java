package MtgServer;

abstract public class GetCmd 
{

    public abstract void run(Server server_i, User usr, Meeting mtg);
    
    public void sendError(String channel, MtgServer.Server server_i, String msg) {
        // try to get the user
        User user = server_i.getUser(channel);
        // get the serverMessage singleton
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg lm;
        // choose language
        if (user == null) lm = sms.getTables(sms.getDefaultLanguage());
        else lm = sms.getTables(user.getLanguage());
        // send message
        server_i.send(channel, new MtgServer.Message(msg, lm.get("server")+":"+this.getClass().getName(), lm.getLanguage())); 
    }
    
    public void sendMsg(User user, MtgServer.Server server_i, String msg) {
        String channel = user.getChannel();
        // get the serverMessage singleton
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg lm;
        // choose language
        if (user == null) lm = sms.getTables(sms.getDefaultLanguage());
        else lm = sms.getTables(user.getLanguage());
        // send message
        server_i.send(channel, new MtgServer.Message(msg, lm.get("server")+":", lm.getLanguage())); 
    }
}
