package MtgServer;

public class DemocraticMtg extends MtgServer.ConcreteMeeting implements MtgServer.Ringable
{

    public User getModerator() {
        return null;
    }
    
    public MeetingTypes getType() {
        return MeetingTypes.Democratic;
    }
    
    public void setModerator(User mod) {
        // NADA
    }
    
    public void broadcast(User user_i, MtgServer.Server server_i, MtgServer.Message message_i) throws MeetingSecurityException, NoUserTransitionException, NoMeetingTransitionException 
    {
        //TODO rollback si ca plante en cours de route sinon
        // risque deadlock.
        
        //the user implicitly asked :
        super.ask(user_i, server_i);
        // automatic hand over by owner:
        super.handOver(user_i, getOwner());
        // send message
        super.broadcast(user_i, server_i, message_i);
        // automatic over from owner
        super.over(user_i);
    }
    
    public void ask(User user_i, Server server_i) throws MeetingSecurityException
    {
        throw new MeetingSecurityException();
    }
    
    /** the current speaking user stops
     * @param user_i the user that performed the operation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void over(User user_i) throws MeetingSecurityException
    {
        throw new MeetingSecurityException();
    }

    /** give the speack to a new user
     * @param newSpeaker_i the user about to speak
     * @param user_i the user that performed the operation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void handOver(User newSpeaker_i, User user_i) throws MeetingSecurityException
    {
        throw new MeetingSecurityException();
    }
    
}
