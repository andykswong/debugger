package MtgServer;

/** Command create : Leave the current user meeting 
 * Syntax of the Enter command
 * <CODE>
 * LEAVE
 *
 * ex : LEAVE
 * </CODE>
 */
public class Leave extends MtgServer.Command
{
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
         User usr = null;
         // The user must be connected
         if ( (usr = checkUser(channel, server_i) ) == null ) return;
         
         // the user must be in a meeting
         Meeting mtg = usr.getCurrentMeeting();
         if (mtg == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("NotInMeeting"));
            return;
         }
         
         // try to leave the meeting
         try {
             mtg.leave(usr, server_i);
         }
         catch (Exception e) {
              sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidOperation"));
         }
    }
    
}
