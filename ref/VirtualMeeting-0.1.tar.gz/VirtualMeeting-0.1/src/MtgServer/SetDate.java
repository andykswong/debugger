package MtgServer;


public class SetDate extends MtgServer.SetCmd
{
    
    public void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i) 
    {
        // get the new date
        String date;
        if (!tokenizer_i.hasMoreTokens()) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("incorrectArguments"));
            return;
        }
        date = tokenizer_i.nextToken(" ");
        
        // try to set the date
        try {
            mtg.setDate(date);
        }
        catch (Exception e) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("invalidDate"));
        }
    }
    
}
