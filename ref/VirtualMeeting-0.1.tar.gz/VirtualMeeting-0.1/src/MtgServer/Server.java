package MtgServer;

import java.util.*;


/**
 * Implementation of the virtual meeting server
 *
 */

public abstract class Server extends Thread
{
    
    /** Current planned, open or close meetings
     */    
    protected Hashtable meetings = new Hashtable();
    /** get a currently active meeting by it's name
     * @param meeting_name the name of the meeting to get
     * @return the meeting which name matches with the given parameter
     * @throws MeetingNotFoundException if there is no meeting having the name given as parameter
     */    
    public MtgServer.Meeting getMeeting (String meeting_name) {
        return (MtgServer.Meeting)this.meetings.get(meeting_name);
    }
    
    public Hashtable getMeetings() {
        return meetings;
    }
  
    /** remove the specified meeting
     * @param meeting_name the name of the meeting to remove
     * @throws MeetingNotFoundException if there is no meeting having the name given as parameter
     */    
    public void removeMeeting (String meeting_name) throws MeetingNotFoundException {
        try {
            this.meetings.remove(meeting_name);
        }
        catch (Exception e) {
            throw new MeetingNotFoundException(meeting_name);
        }
    }
 
    /** the number of active meetings
     * @return the number of active meetings
     */    
    public int cardMeetings () {
        return this.meetings.size();
    }

    /** users connected to the server
     */    
    protected Hashtable users = new Hashtable();

    /** get the user by his channel
     * @param user_channel the channel of the user to get
     * @return the user object which channel matches with the given parameter
     * @throws UserNotFoundException if the is no user on the given channel
     */    
    public MtgServer.User getUser (String user_channel) {
        return (MtgServer.User)this.users.get(user_channel);
    }
    /** Connect a user to the server
     * @param user_channel the channel of the user to add
     * @param user_i the object representing the user
     */    
    public void addUser (String user_channel, MtgServer.User user_i) {
        this.users.put(user_channel, user_i);
    }
    /** remove a user from the server (disconnect her/him)
     * @param user_channel The channel of the user to disconnect
     * @throws UserNotFoundException if the is no user on the given channel
     */    
    public void removeUser (String user_channel) throws UserNotFoundException {
        try {
            this.users.remove(user_channel);
        }
        catch (Exception e) {
            throw new UserNotFoundException("chanel="+user_channel);
        }
    }
    /** number of users connected to the server
     * @return number of users connected to the server
     */    
    public int cardUsers () {
        return this.users.size();
    }

    /** Available commands
     */    
    protected Hashtable commands = new Hashtable();

    /** Time manager (used to auto open democratic meetings)
     */    
    protected MtgServer.TimerManager timerManager;

    /** Tranlator facade (or null if not aivailable)
     */    
    protected MtgServer.Translator translator;
    /** get the translator (null if not available)
     * @return the translator that the system use (null if no translator available)
     */    
    public MtgServer.Translator getTranslator () {
        return this.translator;
    }
    /** set the translator to be used by the system
     * @param value set the translator to be used by the system
     */    
    public void setTranslator (MtgServer.Translator value) {
        this.translator = value; 
    }

    /** Available meeting in the current product
     */    
    protected MtgServer.AvailableMeetings availableMtgs;
    /** get the Available metting set
     * @return the Available metting set
     */    
    public MtgServer.AvailableMeetings getAvailableMtgs () {
        return this.availableMtgs;
    }
    /** set available meetings (called by the factory)
     * @param value the set of available meetings
     */    
    public void setAvailableMtgs (MtgServer.AvailableMeetings value) {
        this.availableMtgs = value; 
    }

    /** Execute a command on the server
     * <CODE>
     * parses the command line : get the user's channel, the name of the command called and the tokenizer corresponding to the arguments of the command.
     * EX. 25?SPEAK meeting1 "my name is Bond"
     *     -> channel = 25
     *        command= SPEAK
     *        arguments = tokenizer(meeting1  "my name is Bond")
     * </CODE>
     * @param commandLine the string of the command to execute
     * @pre commandLine != null && !commandLine.equals("")
     */
    public void exec(String commandLine)
    {
        // build the tokenizer
        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(commandLine);
        
        // get command name and user channel if present else command is ignored
        String channel = null;
        String command = null;
        try {
            channel = tokenizer.nextToken(" ");
            command = tokenizer.nextToken(" ");
        }
        catch (Exception e) {
            // the command is ignored
            return;
        }
        // get the apropriate command
        Command com = (Command)commands.get(command);
        // if command not found send a message to the user and exit
        if (com == null) {
            LanguageMsg lm = langByChannel(channel);
            send(channel, new MtgServer.Message(lm.get("commandNotFound") + " : " + command, lm.get("server"), lm.getLanguage())); 
        }
        else {
            // We invoke the command :
            com.run(channel, tokenizer, this);
        }
    }

    /** send a message to a user
     * @param user_channel the channel of the user
     * @param message_i the message to send
     */    
    public abstract void send(String user_channel, MtgServer.Message message_i);


    /** creates the common commands for all products
     * (called by the factory)
     */    
    public void createCommonCommands()
    {
        addCommand("HANDOVER", new HandOver());
        addCommand("CONNECT", new Connect());
        addCommand("ASK", new Ask());
        addCommand("CREATE", new Create());
        addCommand("ENTER", new Enter());
        addCommand("LEAVE", new Leave());
        addCommand("OPEN", new Open());
        addCommand("SPEAK", new Speak());
        addCommand("CLOSE", new Close());
        addCommand("DISCONNECT", new Disconnect());
        addCommand("SET", new Set());
        addCommand("GET", new Get());
        addCommand("OVER", new Over());
        addCommand("LIST", new List());
    }


    /** Add a common to the current product
     * (called by the factory)
     * @param command_name the name of the command to add
     * @param command_i the command to add
     */    
    public void addCommand(String command_name, MtgServer.Command command_i)
    {
        commands.put(command_name, command_i);
    }

    /** Connect a new user from her/his channel
     * @param name_i the name of the new user
     * @param channel_i channel of the new user
     */    
    public void createAndAddUser(String name_i, String channel_i)
    {
        User nu = new User(name_i, channel_i);
        nu.connect();
        users.put(channel_i, nu);
    }

    /** create and add a new meeting, it's state is set to planned
     * @param name_i the name of the meeting to create and add
     * @param meeting_type the type of meeting to create
     */    
    public void createAndAddMeeting(String name_i, String meeting_type, User owner) throws UnavailableException, NoMeetingTransitionException
    {
        Meeting mtg = availableMtgs.getMeeting(meeting_type);
        if (mtg == null) throw new UnavailableException();
        mtg.plan(name_i, owner);
        meetings.put(name_i, mtg);
    }

    /** get the object representig a user by it's name
     * (to call as less as posible)
     * @param name_i the name of the user to get
     * @return the user that have the given name
     * @throws UserNotFoundException if the server does not have any user with the given name
     */    
    public MtgServer.User getUserByName(String name_i)
    {
        java.util.Iterator us = users.values().iterator();
        User Result = null;
        while (us.hasNext()) {
            Result = (User)us.next();
            if (Result.getName().equals(name_i)) return Result;
        }
       return null;
    }
    
    /** get the messages in the apropiate language for a channel
     * returns the user language if a user is connected on the channel
     * and the default language of the product is other cases.
     *@parm channel the channel
     *@return the apropriate LanguageMsg
     */
    public LanguageMsg langByChannel(String channel) {
        // get the user
        User user = (User)users.get(channel);
        // get the SrrverMessage
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg Result;
        if (user == null) Result = sms.getTables(sms.getDefaultLanguage());
        else Result = sms.getTables(user.getLanguage());
        return Result;
    }
    
    public String dump() {
        String Result = "Virtual Meeting Server dump :\n";
        Result += "USERS :\n";
        Enumeration enum = users.keys();
        User usr;
        while(enum.hasMoreElements()) {
            usr = getUser((String)enum.nextElement());
            Result += "  " + usr.dump() + "\n";
        }
        Result += "MEETINGS :\n";
        enum = meetings.keys();
        Meeting mtg;
        while(enum.hasMoreElements()) {
            mtg = getMeeting((String)enum.nextElement());
            Result += "  " + mtg.dump() + "\n";
        }
        Result += "--------------------------------";
        return Result;
    }
}
