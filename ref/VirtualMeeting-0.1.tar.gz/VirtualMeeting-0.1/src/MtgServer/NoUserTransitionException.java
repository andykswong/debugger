/*
 * NoUserTransition.java
 *
 * Created on 13 juillet 2002, 00:23
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class NoUserTransitionException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>NoUserTransition</code> without detail message.
     */
    public NoUserTransitionException() {
    }
    
    
    /**
     * Constructs an instance of <code>NoUserTransition</code> with the specified detail message.
     * @param msg the detail message.
     */
    public NoUserTransitionException(String msg) {
        super(msg);
    }
}
