package MtgServer;

/**
 * DISCONNECT COMMAND
 *
 * NOT IMPLEMENTED
 * ( do nothing )
 *
 * Removing the user from the server is a bad idea, this shoud be handeled
 * by the server itself when it looses the user connection.
 * Disconnection is not a command.
 *
 */
public class Disconnect extends MtgServer.Command
{    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        
    }
    
}
