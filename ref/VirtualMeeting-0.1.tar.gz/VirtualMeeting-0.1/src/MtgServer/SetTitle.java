package MtgServer;


public class SetTitle extends MtgServer.SetCmd
{   
    public void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i) 
    {
        // get the new Title
        String title = "";
        while(tokenizer_i.hasMoreTokens()) title += tokenizer_i.nextToken(" ") + " ";
        title = title.trim();
        mtg.setTitle(title);
    }
    
}
