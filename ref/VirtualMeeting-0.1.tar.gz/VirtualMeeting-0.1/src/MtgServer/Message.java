package MtgServer;


/** Class representing a message to send
 */
public class Message 
{
    protected languages language;

    /** Text of the message
     */    
    protected String text;
    
    /** Origin of the message.
     * The name of the meeting or Server if it an information message from the server
     */    
    protected String sender;

    /** get the text of the message
     * @return the text of the message
     */    
    public String getText () {
        return this.text;
    }

    /** get the origin of the message
     * @return the origin of the message
     */    
    public String getSender () {
        return this.sender;
    }
    
    /** set the origin of the message
     * @param sender_i the origin of the message
     */    
    public void setSender(String sender_i) {
        sender = sender_i;
    }
    
    /** Getter for property language.
     * @return Value of property language.
     */
    public MtgServer.languages getLanguage() {
        return language;
    }
    
    /** Setter for property text.
     * @param text New value of property text.
     */
    public void setText(java.lang.String text) {
        this.text = text;
    }
    
    /** Setter for property language.
     * @param language New value of property language.
     */
    public void setLanguage(MtgServer.languages language) {
        this.language = language;
    }
    
    /** create a message
     * @param text_i the text of the message
     * @param sender_i the origin of the message
     * @language_i the language of the message
     */    
    public Message(String text_i, String sender_i, languages language_i) {
        text = text_i;
        sender = sender_i;
        language = language_i;
    }
    
    /** create a message without sender, the method setSender should
     * be called before sending the message.
     * @param text_i the text of the message
     * @language_i the language of the message
     */    
    public Message(String text_i, languages language_i) {
        text = text_i;
    }
}
