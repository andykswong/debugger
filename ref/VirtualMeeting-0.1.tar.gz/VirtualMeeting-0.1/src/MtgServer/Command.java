package MtgServer;

/** A command that the server can execute
 */
abstract public class Command 
{

    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */    
    public abstract void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i);
    
    /** send an "incorrect command arguments" message to a user by his channel
     * If the used exist in the server, the message is sent in her/his language
     * If it does not the message is sent using the default language of the server
     * @param channel The channel of the user that executes the command
     * @param msg the message to send
     * @param server_i the virtual meeting server to perform command on
     */
    public void sendIncorrectArgs(String channel, MtgServer.Server server_i, String msg) {
        // try to get the user
         User user = server_i.getUser(channel);
        // get the serverMessage singleton 
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg lm;
        // choose language
        if (user == null) lm = sms.getTables(sms.getDefaultLanguage());
        else lm = sms.getTables(user.getLanguage());
        // send message
        server_i.send(channel, new MtgServer.Message(lm.get("incorrectArguments") + " " + msg, lm.get("server")+":"+this.getClass().getName(),lm.getLanguage())); 
    }
    
    /** send an "incorrect command arguments" message to a user by his channel
     * If the used exist in the server, the message is sent in her/his language
     * If it does not the message is sent using the default language of the server
     * @param channel The channel of the user that executes the command
     * @param msg the message to send
     * @param server_i the virtual meeting server to perform command on
     */
    public void sendError(String channel, MtgServer.Server server_i, String msg) {
        // try to get the user
        User user = server_i.getUser(channel);
        // get the serverMessage singleton
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg lm;
        // choose language
        if (user == null) lm = sms.getTables(sms.getDefaultLanguage());
        else lm = sms.getTables(user.getLanguage());
        // send message
        server_i.send(channel, new MtgServer.Message(msg, lm.get("server")+":"+this.getClass().getName(), lm.getLanguage())); 
    }
    
    public User checkUser(String channel, MtgServer.Server server_i) {
        User usr;
        if ((usr = server_i.getUser(channel)) == null)
            sendError(channel, server_i, server_i.langByChannel(channel).get("userNotConnected"));
        return usr;
    }
}
