package MtgServer;
/** Abstract root class for all types of meetings
 */
public abstract class ConcreteMeeting implements MtgServer.Meeting, Cloneable
{

    /** the current sate of the meeting (implemented with a State design pattern)
     */    
    protected MtgServer.MeetingState currentState;
    
    /** The identifier of the meeting
     */    
    protected String name;
    
    /** title or descrition of the meeting
     */    
    protected String title;

    /** theme of the meeting
     */    
    protected String agenda;

    /** Planned duration of the meeting
     */    
    protected String duration;

    /** Date of the beginning of the meeting
     */    
    protected java.util.GregorianCalendar date;

    /** Date of the end of the meeting
     */    
    protected java.util.GregorianCalendar endDate;
    
     /** Users curently in the meeting
     */    
    protected java.util.Hashtable users;
    
    /** the creator of the meeting
     */    
    protected User owner;
    
    /** get the state of the meeting
     * @return the state of the meeting
     */    
    public MtgServer.MeetingState getCurrentState () {
        return this.currentState;
    }
    
     /** Setter for property currentState.
     * @param currentState New value of property currentState.
     */
    public void setCurrentState(MtgServer.MeetingState currentState) {
        this.currentState = currentState;
    }
 
    /** get the users connected to this meeting
     * @return the users connected to this meeting
     */    
    public java.util.Hashtable getUsers() {
        return users;
    }
    
    /** get a user by his channel
     * @param channel the channel of the user to get
     * @return the user that has the given channel or null if not found
     */    
    public MtgServer.User getUser (String channel) {
        return (MtgServer.User)this.users.get(channel);
    }
    
    /** get the number of user currently in the meeting
     * @return the number of user currently in the meeting
     */    
    public int cardUsers () {
        return this.users.size();
    }


    /** method that initialize the meeting and put it in the planned state
     * @param name_i name of the meeting
     * @param user_i the user that performed the opperation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void plan(String name_i, MtgServer.User user_i) throws NoMeetingTransitionException
    {
        if (currentState != null)
            throw new NoMeetingTransitionException();
        name = name_i;
        owner = user_i;
        title = "";
        agenda = "";
        duration = "";
        users = new java.util.Hashtable();
        // Initialize the state to planned :
        setCurrentState(Planned.getInstance());
    }


    /** Open the meeting (try to change state)
     * @param user_i the user that performed the opperation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void open(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException
    {
        if (user_i == getModerator() || user_i == getOwner())
            currentState.open(this);
        else throw new MeetingSecurityException();
    }

    /** try to close the meeting
     * @param user_i the user that performed the opperation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void close(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException
    { 
        if (user_i == getModerator() || user_i == getOwner())
            currentState.close(this);
        else throw new MeetingSecurityException();
    }
    
    /** the current speaking user stops
     * @param user_i the user that performed the operation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void over(User user_i) throws NoMeetingTransitionException, MeetingSecurityException
    {
        currentState.over(this);
    }

    /** give the speack to a new user
     * @param newSpeaker_i the user about to speak
     * @param user_i the user that performed the operation
     * @throws NoMeetingTransitionException if the operation is impossible
     */    
    public void handOver(User newSpeaker_i, User user_i) throws NoMeetingTransitionException, MeetingSecurityException
    {
        currentState.handOver(newSpeaker_i, this);
    }

    /** broadcasts a message over all connected users
     * @param server_i the server to use to broadcast the message
     * @param message_i the message to broadcast
     * @throws MeetingSecurityException speaking in the meeting is not possible because the meeting
     * is not open or the user trying to speak is not allowed to.
     */    
    public void broadcast(User user_i, MtgServer.Server server_i, MtgServer.Message message_i) throws MeetingSecurityException, NoUserTransitionException, NoMeetingTransitionException
    {
        currentState.broadcast(this,server_i, message_i);
    }

    /** get the title of the meeting
     * @return the title of the meeting
     */    
    public String getTitle()
    {
        return this.title;
    }

    /** get the begining date of the meeting
     * @return the begining date of the meeting
     */    
    public java.util.GregorianCalendar getDate()
    {
        return this.date;
    }

    /** get the duration of the meeting (string formated)
     * @return the duration of the meeting
     */    
    public String getDuration()
    {
        return this.duration;
    }

    /** get the theme of the meeting
     * @return the theme of the meeting
     */    
    public String getAgenda()
    {
        return this.agenda;
    }

    /** set the tile of the meeting
     * @param title_i the tile of the meeting
     */    
    public void setTitle(String title_i)
    {
        title = title_i;
    }

    /** set the date of the meeting
     * @param date_i set the date of the meeting
     */    
    public void setDate(String date_i)
    {
        // TODO : parse the string to set the date variable
    }

    /** set the duration of the meeting
     * @param duration_i the duration of the meeting
     */    
    public void setDuration(String duration_i)
    {
        // TODO : parse the string to set the date variable
    }

    /** set the theme of the meeting
     * @param agenda_i the theme of the meeting
     */    
    public void setAgenda(String agenda_i)
    {
        this.agenda = agenda_i;
    }
    
    /** get the meeting creator
     * @return the meeting creator
     */    
    public MtgServer.User getOwner() {
        return owner;
    }    
    
    
    /** get the meeting moderator
     * @return the meeting moderator
     */    
    public abstract User getModerator();
    
    /** get the type of the meeting (private, democrotic or standard)
     * @return the type of the meeting
     */    
    public abstract MeetingTypes getType();
    
    /** add a user to the meeting
     * @param user_i the user that entered the meeting
     */   
    public void enter(User user_i, Server server_i) throws MeetingSecurityException, NoUserTransitionException {
       
       // the first idea is to pass this to the user but it
       // is an error : it may have decorations....
       user_i.enter(server_i.getMeeting(name));
       users.put(user_i.getChannel(), user_i);
       
       // try to broadcast welcome message (will work only if the
       // meeting is in the open state).
          /* TODO */
       
    }
    
    /** supress a user from the meeting
     * @param user_i the user that left the meeting
     */    
    public void leave(User user_i, Server server_i) throws NoUserTransitionException {
        user_i.leave(server_i.getMeeting(name));
        users.remove(user_i.getChannel());
        
        // try to broadcast BYE-BYE message (will work only if the
       // meeting is in the open state).
          /* TODO */
    }

    /** The user that performed the operation is asking to speak in the meeting
     * @param user_i the user that performed the operation
     */    
    public void ask(User user_i, Server server_i) throws NoUserTransitionException, MeetingSecurityException {
        user_i.askPermission(server_i.getMeeting(name));
    }

    /** transforms the string given in parameter into a number of milliseconds.
     *
     * @param duration_i the duration hh:mm
     * @returns the number of ms corresponding to the given duration
     * @return the number of millisecond corresponding to the given string
     * @throws DateFormatException if the given string isn't correct
     * @throws NumberFormatException if the given string isn't correct
     */
    protected long stringToMs(String duration_i) throws DateFormatException, NumberFormatException
    {
        java.util.StringTokenizer tkz = new java.util.StringTokenizer(duration_i);
        long result = 0;
        if (tkz.hasMoreTokens())
            result += Integer.parseInt(tkz.nextToken(":")) * 3600000;
        else throw new DateFormatException();
        if (tkz.hasMoreTokens())
            result += Integer.parseInt(tkz.nextToken(":")) * 1000;
        else throw new DateFormatException();
        return result;
    }
    
     /** implementation of the Cloneable interface
     * @return a fiels by fiels copy of the current object
     */    
    public Object clone() {
        try {
            return super.clone();
        }
        catch (Exception e) { e.printStackTrace(); }
        return null;
    }
    
    /** get the identifier of the meeting in the server table
     * @return the identifier of the meeting in the server table
     */    
    public String getName() {
        return name;
    }
    
    /** set the moderator of the meeting
     * 
     * @param mod the new moderator
     */
    public abstract void setModerator(User mod);
    
    public String dump() {
        String Result = "";
        Result += getName() + " " + currentState.getClass().getName();
        return Result;
    }
    
}
