package MtgServer;

/** Class representing a set of available meetings.
 */
public class AvailableMeetings 
{

    /** HashTable containing available meetings
     */    
    protected java.util.Hashtable mtgs = new java.util.Hashtable();
    
    /** Returns the meeting corresponding to the type of meeting given in parameter or null
     * if required type of meeting is not available.
     * The returned meeting is a clone of the one retrived from the hashtable.
     * @return An instance of meeting or null if required type of meeting is not available
     * @param meeting_type The name of the type of meeting to get (standard, democratic, private)
     */    
    public Meeting getMeeting(String meeting_type) {
        // get the required meeting
        Meeting Result = (Meeting)mtgs.get(meeting_type);
        // Clone it if it was found
        if (Result != null) Result = (Meeting)Result.clone();
        return Result;
    }
    
    /** Add a meeting in the set of available meetings, the given meeting object should be just created.
     * This method should only be called by the server factory in order to add available meeting in the product
     * @param meeting_type The name of the type of meeting to add (standard, democratic, private)
     * @param meeting_i The just created meeting object corresponding to the given type name
     */    
    public void addMeeting(String meeting_type, Meeting meeting_i) {
        mtgs.put(meeting_type, meeting_i);
    }
    
    /** Get the number of available meeting.
     * @return the number of available meeting.
     */    
    public int cardMtgs () {
        return this.mtgs.size();
    }

}
