package MtgServer;


/** Planned meeting state
 */
public class Planned extends MtgServer.MeetingState {
    
    /** Implementation of the singleton pattern
     */    
    protected static Planned singleton = null;
    
    /** Implementation of the singleton pattern
     * @return The only instance of the Planned state
     */    
    public static Planned getInstance() {
        if(singleton == null) singleton = new Planned();
        return singleton;
    }
    
    /** Implementation of the singleton pattern
     */    
    protected Planned() {}
    
    /** Trasition to the Opened state
     */
     public void open(MtgServer.ConcreteMeeting meeting_i) {
        meeting_i.setCurrentState(Opened.getInstance());
    }
    
}
