/*
 * Language.java
 *
 * Created on 10 juillet 2002, 22:56
 */

package MtgServer;

/** Base class for all languages classes
 */
public abstract class LanguageMsg {
    
    /** the language of the current language object
     */    
    protected languages language;
    
    /** get the language of the current object
     * @return the language of the current object
     */    
    public languages getLanguage() {
        return language;
    }
    
    /** table of messages
     */    
    protected java.util.Hashtable messages = new java.util.Hashtable();
    
    /** Creates a new instance of Language */
    public LanguageMsg() {
        
    }
    
    /** get the message fron its ID string
     * first look in the table of messages in the current language and if not found try to get the message
     * from the defaut message table (in english). this is to allow partial traduction of the server messages.
     *
     * @param id_message the ID string of the message to get
     * @return the string of the message
     */    
    public String get(String id_message) {
        String result = (String)messages.get(id_message);
        if (result == null) result = id_message;
        return result;
    }
    
}
