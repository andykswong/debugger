package MtgServer;


public class LimitedMeeting extends MtgServer.Decorator
{
    
    protected int limit;
    protected int nb_users;
    
    public LimitedMeeting(int limit_i, Meeting component_i) {
        super(component_i);
        limit = limit_i;
        nb_users = 0;
    }
    
     public void enter(User user_i, Server server_i) throws MeetingSecurityException, NoUserTransitionException {
         if (nb_users < limit) {
            super.enter(user_i, server_i);
            nb_users++;
         }
         else throw new MeetingSecurityException();
     }
     
      public void leave(User user_i, Server server_i) throws NoUserTransitionException {
        super.leave(user_i, server_i);
        nb_users--;
        //System.out.println("DEBUG : LEAVE -> " + nb_users +"/" + limit);
    }
      
    public String dump() {
        return component.dump() + " limited : "+ nb_users +"/" + limit;
    }
}
