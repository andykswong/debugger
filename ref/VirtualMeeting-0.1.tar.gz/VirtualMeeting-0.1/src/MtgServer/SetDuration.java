package MtgServer;


public class SetDuration extends MtgServer.SetCmd {
    
    public void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i) 
    {
         // get the duration
        String duration;
        if (!tokenizer_i.hasMoreTokens()) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("incorrectArguments"));
            return;
        }
        duration = tokenizer_i.nextToken(" ");
        
        // try to set the date
        try {
            mtg.setDuration(duration);
        }
        catch (Exception e) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("invalidDuration"));
        }
    }
}
