/*
 * List.java
 *
 * Created on 15 juillet 2002, 20:27
 */

package MtgServer;

/** Syntax of the connect list
 * <CODE>
 * LIST
 * 
 * get the list of available meetings on the current server
 * </CODE>
 */
public class List extends Command {
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) {
        
        User usr = null;
        // The user must be connected
        if ( (usr = checkUser(channel, server_i) ) == null ) return;
        
        // get the meeting list from server
        String mtgs = "";
        java.util.Enumeration enum = server_i.getMeetings().keys();
        while(enum.hasMoreElements()) {
            mtgs = enum.nextElement().toString() + " ";
        }
        mtgs = mtgs.trim();
        
        
        //create the message to send
        ServerMessages sms = ServerMessages.getInstance();
        LanguageMsg lm;
        lm = sms.getTables(usr.getLanguage());
        MtgServer.Message msg = new Message(mtgs, lm.get("server"), lm.getLanguage());
        
        // send message
        server_i.send(channel, msg); 
    }
    
}
