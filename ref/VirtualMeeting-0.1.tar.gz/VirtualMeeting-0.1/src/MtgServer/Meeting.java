package MtgServer;
/** Interface that defined the public interface of any meeting
 */
public interface Meeting
{
     // meeting state :
     void plan(String name, MtgServer.User user_i) throws NoMeetingTransitionException;
     void open(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException;
     void close(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException;
     void over(MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException;
     void handOver(MtgServer.User newSpeaker_i, MtgServer.User user_i) throws NoMeetingTransitionException, MeetingSecurityException;
     
     // user interactions :
     void broadcast(User user_i, MtgServer.Server server_i, MtgServer.Message message_i) throws MeetingSecurityException, NoUserTransitionException, NoMeetingTransitionException;
     void enter(User user_i, Server server_i) throws MeetingSecurityException, NoUserTransitionException;
     void leave(User user_i, Server server_i) throws NoUserTransitionException;
     void ask(User user_i, Server server_i) throws NoUserTransitionException, MeetingSecurityException;
     
     // properties get/set :
     String getName();
     String getTitle();
     void setTitle(String title_i);
     User getModerator();
     void setModerator(User mod);
     User getOwner();
     java.util.GregorianCalendar getDate();
     void setDate(String date_i);
     String getDuration();
     void setDuration(String duration_i);
     MeetingTypes getType();
     String getAgenda();
     void setAgenda(String agenda_i);
     
     // Clone operation
     Object clone();
     
     // debug dump operation
     String dump();
}
