/*
 * Spanish.java
 *
 * Created on 10 juillet 2002, 23:03
 */

package MtgServer;

/**
 *Spanish set of messages
 */
public class SpanishMsg extends LanguageMsg {
    
    /** 
     * Creates a new instance of Spanish and set messages in spanish.
     */
    public SpanishMsg() { 
        // call the constructor of the super class
        super();
        // set the current language
        this.language = languages.Spanish;
        // add translated messages
        // translation comes from google
        // I'm not responsable for these !
        messages.put("commandNotFound","Comando no encontrado");
        messages.put("incorrectArguments","Discusiones incorrectas");
        messages.put("unexpectedError","Error inesperado");
        messages.put("server","Servidor");
        messages.put("meetingNotFound","El satisfacer no encontrado");
        messages.put("userNotFound","Usuario no encontrado");
    }
    
}
