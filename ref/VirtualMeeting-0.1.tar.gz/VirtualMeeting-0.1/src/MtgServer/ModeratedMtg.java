package MtgServer;



public abstract class ModeratedMtg extends MtgServer.ConcreteMeeting
{

    private MtgServer.User moderator;
   
    public MtgServer.User getModerator () {
        return this.moderator;
    }
    
    public void setModerator(User mod) {
        moderator = mod;
    }
    
    /** The user that performed the operation is asking to speak in the meeting
     * @param user_i the user that performed the operation
     */
    public void ask(MtgServer.User user_i, Server server_i) throws NoUserTransitionException, MeetingSecurityException {
        super.ask(user_i, server_i);
        // notify the moderator if not null
        if (moderator != null) {
            LanguageMsg lm = ServerMessages.getInstance().getTables(moderator.getLanguage());
            MtgServer.Message msg = new Message(user_i.getName() + lm.get("AskingToSpeak"), 
                                                lm.get("Server")+":"+getName(), lm.getLanguage());
            moderator.send(server_i, msg);
        }
    }
    
    public abstract MeetingTypes getType();
    
}
