package MtgServer;

/** Syntax of the CHOOSELANGUAGE command
 * <CODE>
 * CHOOSELANGUAGE [language] 
 *      [language] = { English | French | Spanish }
 * ex : CHOOSELANGUAGE French
 *
 * (must be performed by the meeting moderator)
 * </CODE>
 */
public class ChooseLanguage extends MtgServer.Command
{
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        User usr = null;
        // The user must be connected
        if ( (usr = checkUser(channel, server_i) ) == null ) return;
        
        // get the language
        String lang;
        if (tokenizer_i.hasMoreTokens())
            lang = tokenizer_i.nextToken(" ");
         else {
            this.sendIncorrectArgs(channel,server_i,"ENTER [meeting_name]");
            return; 
         }
        
        // get the language object
        languages nlang = languages.fromString(lang);
        if (nlang == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidLanguage"));
            return;
        }
        
        usr.setLanguage(nlang);
    }
    
}
