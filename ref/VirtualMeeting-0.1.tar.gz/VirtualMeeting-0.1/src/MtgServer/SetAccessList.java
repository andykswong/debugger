package MtgServer;

public class SetAccessList extends MtgServer.SetCmd
{
    public void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i) 
    {
        
        // check if private meeting
        if (mtg.getType() != MeetingTypes.Private) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("NotPrivateMtg"));
            return;
        }
        // get the private meeting object
        PrivateMtg pmtg = (PrivateMtg)mtg;
        
        // Add users to the acces list
        String name;
        User ausr;
        while (tokenizer_i.hasMoreTokens()) {
            name = tokenizer_i.nextToken(" ");
            ausr = server_i.getUserByName(name);
            if (ausr == null) sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("UnknownUser"));
            else pmtg.setAuthorized(ausr);
        }
    }
    
}
