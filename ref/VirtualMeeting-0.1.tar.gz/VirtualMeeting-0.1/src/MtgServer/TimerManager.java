package MtgServer;

// objecteering-startJavadoc....................................N/TMB/CU7EYL1:C8
// objecteering-endJavadoc......................................E/TMB/CU7EYL1:C8
public class TimerManager 
{
// objecteering-startJavadoc....................................N/5BC/0PELHP1:Z8
// objecteering-endJavadoc......................................E/5BC/0PELHP1:Z8
    protected java.util.Vector timers = new java.util.Vector();
    public MtgServer.SoftTimer getTimers (int i) {
        return (MtgServer.SoftTimer)this.timers.elementAt(i);
    }
    public int cardTimers () {
        return this.timers.size();
    }

}
