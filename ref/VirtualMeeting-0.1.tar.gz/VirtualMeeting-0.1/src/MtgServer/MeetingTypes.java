package MtgServer;


// objecteering-startJavadoc...................................N/98N/0PELHP1:652
// objecteering-endJavadoc.....................................E/98N/0PELHP1:652
public class MeetingTypes implements java.io.Serializable
{
    private int value;
    private static final String[] strValues = {"democratic",
                                                                "standard",
                                                                "private"
                                                                };

    public static final MeetingTypes Democratic = new MeetingTypes(0);
    public static final MeetingTypes Standard = new MeetingTypes(1);
    public static final MeetingTypes Private = new MeetingTypes(2);

    private static final MeetingTypes[] enumValues = {Democratic,
                                                                        Standard,
                                                                        Private
                                                                        };

    private MeetingTypes(int code) {
        value = code;
    }

    public java.lang.String toString () {
        return strValues[value];
    }

    public int toInt () {
        return value;
    }

    public static MeetingTypes fromString (String str) {
        MeetingTypes toReturn = null;
        int i = 0;

        while (i < strValues.length)
        {
            if (strValues[i].equals(str))
                toReturn = enumValues[i];
            i++;
        }
        return toReturn;
    }

}
