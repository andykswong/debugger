package MtgServer;


public class GetAccessList 
    extends MtgServer.GetCmd
{    
    public void run(Server server_i, User usr, Meeting mtg) 
    {
        // check if private meeting
        if (mtg.getType() != MeetingTypes.Private) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("NotPrivateMtg"));
            return;
        }
        // get the private meeting object
        PrivateMtg pmtg = (PrivateMtg)mtg;
        
        //Compute access list
        String list = "";
        java.util.Hashtable usrs = pmtg.getAuthorized();
        User u;
        java.util.Iterator it = usrs.values().iterator();
        while(it.hasNext()) {
            u = (User)it.next();
            list += u.getName() + " ";
        }
        list = list.trim();
        sendMsg(usr, server_i, list);
    }
    
}
