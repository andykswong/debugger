package MtgServer;


public class InMeeting extends MtgServer.UserState
{
    
    /** Implementation of the singleton pattern : only instance of the concrete user state
     */    
    protected static UserState singleton = null;
    
    /** Implementation of the singleton Design Pattern
     * @return the only instance of the concrete state
     */    
    public static UserState getInstance() {
        if (singleton == null) singleton = new InMeeting();
        return singleton;
    }
    
    /** Implementation of the singleton Design Pattern
     */    
    protected InMeeting() {}

    public void leave(MtgServer.Meeting meeting, MtgServer.User user_i)
    {
        user_i.setCurrentState(Registered.getInstance());
    }

    public void askPermission(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        try {
            user_i.setCurrentState(WaitingToSpeak.getInstance());
        }
        catch (Exception e) {
            throw new NoUserTransitionException();
        }
    }
}
