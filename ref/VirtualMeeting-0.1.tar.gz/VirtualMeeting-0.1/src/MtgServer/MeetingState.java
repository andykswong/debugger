package MtgServer;


/** Implementation of the state desin pattern. this is the root class
 * for each state of any meeting. it defined the default behavior of
 * every method : throws an error...
 * Each state is implmented using the singleton pattern.
 */
abstract public class MeetingState 
{

    /** open the meeting
     * @param meeting_i the meeting to open
     * @param user_i the user that performed the operation
     */    
    public void open(MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        throw new NoMeetingTransitionException();
    }


    /** close a meeting
     * @param meeting_i the meeting to close
     * @param user_i the user that performed the operation
     */    
    public void close(MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        throw new NoMeetingTransitionException();
    }

    /** the current talk is over
     * @param meeting_i the concerned meeting
     * @param user_i the user that performed the operation
     */    
    public void over(MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        throw new NoMeetingTransitionException();
    }

    /** gives the speak to a user
     * @param newSpeaker_i the new speaker
     * @param meeting_i the concerned meeting
     * @param user_i the user that performed the operation
     */    
    public void handOver(MtgServer.User newSpeaker_i, MtgServer.ConcreteMeeting meeting_i) throws NoMeetingTransitionException
    {
        throw new NoMeetingTransitionException();
    }
    
    public void broadcast(MtgServer.ConcreteMeeting meeting_i, Server server_i, Message msg) throws MeetingSecurityException
    {
        throw new MeetingSecurityException();
    }


}
