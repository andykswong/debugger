package MtgServer;


public class SetModerator extends MtgServer.SetCmd
{
    
    public void run(Server server_i, Meeting mtg, User usr, java.util.StringTokenizer tokenizer_i) {
        String name;
        User mod;
        
        // get the moderator name :
        if(!tokenizer_i.hasMoreTokens()) {
           sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("incorrectArguments"));
           return;
        }
        name = tokenizer_i.nextToken(" ");
        
        // get the corresponding user :
        mod = server_i.getUserByName(name);
        if (mod == null) {
            sendError(usr.getChannel(), server_i, server_i.langByChannel(usr.getChannel()).get("UnknownUser"));
            return;
        }
        
        // set the moderator :
        mtg.setModerator(mod);
    }
    
}
