package MtgServer;


/** Syntax of the connect command
 * <CODE>
 * CONNECT [user_name]
 * ex : CONNECT bond
 * </CODE>
 */
public class Connect 
    extends MtgServer.Command
{
    
    /** Connect the new user
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        
        // check if user isn't already connected
        if (server_i.getUser(channel) != null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("alreadyConnected"));
            return;
        }
        
        String name = null;
        // is there a user name ?
        if (!tokenizer_i.hasMoreTokens()) {
            this.sendIncorrectArgs(channel,server_i,"CONNECT [user_name]");
            return;
        } 
        // get the name
        name = tokenizer_i.nextToken(" ");
        
        // check if it does not already exists
        if (server_i.getUserByName(name) != null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("nameAlreadyUsed"));
            return;
        }
        
        // create the user and add if to the server
        server_i.createAndAddUser(name, channel);
    }
    
}
