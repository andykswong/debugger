package MtgServer;

/** speak command : to brodcast a message in the current meeting
 * Syntax of the Speak command
 * <CODE>
 * SPEAK [message]
 *
 * ex : SPEAK hi! my name is Bond, James Bond
 * </CODE>
 */
public class Speak extends MtgServer.Command
{    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
         User usr = null;
         // The user must be connected
         if ( (usr = checkUser(channel, server_i) ) == null ) return;
         
         // the user must be in a meeting
         Meeting mtg = usr.getCurrentMeeting();
         if (mtg == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("NotInMeeting"));
            return;
         }
         
        // get the message :
        String msg = "";
        while(tokenizer_i.hasMoreTokens()) msg += tokenizer_i.nextToken(" ") + " ";
        msg = msg.trim();
        // check for empty message
        if (msg.equals("")) {
            this.sendIncorrectArgs(channel,server_i,"SPEAK [message]");
            return; 
        }
        
        // try to broadcast message
        try {
             Message m = new MtgServer.Message(msg, usr.getName(), usr.getLanguage());
             mtg.broadcast(usr, server_i, m);
         }
         catch (Exception e) {
              sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidOperation"));
         }
    }
    
}
