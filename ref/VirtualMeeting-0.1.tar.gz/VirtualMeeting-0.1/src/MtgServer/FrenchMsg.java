/*
 * French.java
 *
 * Created on 10 juillet 2002, 23:00
 */

package MtgServer;

/**
 *French set of messages
 */
public class FrenchMsg extends LanguageMsg {
    
    /** 
     * Creates a new instance of French and set messages in french.
     */
    public FrenchMsg() {
        // call the constructor of the super class
        super();
        // set the current language
        this.language = languages.French;
        // add translated messages
        messages.put("commandNotFound","Commande non trouv�e");
        messages.put("incorrectArguments","Arguments incorctes");
        messages.put("unexpectedError","Erreur innatendue");
        messages.put("server","Serveur");
        messages.put("meetingNotFound","Impossible de trouver le meeting");
        messages.put("userNotFound","Impossible de trouver l'utilisateur");
    }
    
}
