package MtgServer;

/** Abstract root class for every user state
 * if defined default error handeling
 */
abstract public class UserState 
{ 
    /** enter a meeting
     * @param meeting the meeting to enter in
     * @param user_i the user on which perform operation
     */    
    public void enter(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        throw new NoUserTransitionException();
    }

    /** leave a meeting
     * @param meeting the meeting to leave
     * @param user_i the user on which perform operation
     */    
    public void leave(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        throw new NoUserTransitionException();
    }

    /** enter in the speaking state in a meeting
     * @param meeting the meeting to speak into
     * @param user_i the user on which perform operation
     */    
    public void handOver(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        throw new NoUserTransitionException();
    }

    /** Ask to speak in a meeting
     * @param meeting the meeting to speak into
     * @param user_i the user on which perform operation
     */    
    public void askPermission(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        throw new NoUserTransitionException();
    }
    
    /** don't speak anymore
     * @param meeting the meeting to speak into
     * @param user_i the user on which perform operation
     */    
    public void over(MtgServer.Meeting meeting, MtgServer.User user_i) throws NoUserTransitionException
    {
        throw new NoUserTransitionException();
    }
}
