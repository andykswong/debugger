/*
 * UserNotFoundException.java
 *
 * Created on 11 juillet 2002, 00:50
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class UserNotFoundException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>UserNotFoundException</code> without detail message.
     */
    public UserNotFoundException() {
    }
    
    
    /**
     * Constructs an instance of <code>UserNotFoundException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public UserNotFoundException(String msg) {
        super(msg);
    }
}
