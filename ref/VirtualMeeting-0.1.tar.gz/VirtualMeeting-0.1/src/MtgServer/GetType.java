package MtgServer;


public class GetType extends MtgServer.GetCmd
{
    public void run(Server server_i, User usr, Meeting mtg) 
    {
        // send the message
        sendMsg(usr, server_i, mtg.getType().toString());
    }
    
}
