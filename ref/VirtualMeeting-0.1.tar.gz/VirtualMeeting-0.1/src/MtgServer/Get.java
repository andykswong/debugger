package MtgServer;
/** Command get : get meeting's fields
 * Syntax of the GET command
 * <CODE>
 * GET [meeting_name] [FIELD]
 * FIELD = {MODERATOR | ACCESSLIST | DATE | DURATION | TITLE | AGENDA | TYPE}
 * ex : GET secrete_meeting AGENDA
 * ex : GET secrete_meeting ACCESSLIST
 * ex : GET secrete_meeting MODERATOR
 * </CODE>
 */
public class Get 
    extends MtgServer.Command
{
    protected java.util.Hashtable commands = new java.util.Hashtable();
    
    public Get() {
        createCommands();
    }
    
    private void createCommands() {
        commands.put("MODERATOR", new GetModerator());
        commands.put("ACCESSLIST", new GetAccessList());
        commands.put("DATE", new GetDate());
        commands.put("DURATION", new GetDuration());
        commands.put("TITLE", new GetTitle());
        commands.put("TYPE", new GetType());
        commands.put("AGENDA", new GetAgenda());
        
    }
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
        User usr;
        // The user must be connected
        if ( (usr = checkUser(channel, server_i) ) == null ) return;
        
        // get the meeting name and the command
        String m_name, comm;
        
        // get the meeting name :
        if (tokenizer_i.hasMoreTokens())
            m_name = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"GET [meeting_name] [FIELD]");
            return; 
        }
        
        //get the field to set
        if (tokenizer_i.hasMoreTokens())
            comm = tokenizer_i.nextToken(" ");
        else {
            this.sendIncorrectArgs(channel,server_i,"GET [meeting_name] [FIELD]");
            return; 
        }
        
        // check the meeting :
        Meeting mtg = server_i.getMeeting(m_name);
        if (mtg == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidMeeting"));
            return;
        }
        
        // get the command
        GetCmd com = (GetCmd)commands.get(comm);
        if (com == null) {
            this.sendIncorrectArgs(channel,server_i,"GET [meeting_name] [FIELD]");
            this.sendIncorrectArgs(channel,server_i,"FIELD = {MODERATOR | ACCESSLIST | DATE | DURATION | TITLE | AGENDA | TYPE}");
            return;
        }
        
        // invoke the command
        com.run(server_i, usr, mtg);
    }
}
