package MtgServer;



/** User state Registered : the user is connected to a server but is not currently in a meeting
 */
public class Registered extends MtgServer.UserState
{

    /** Implementation of the singleton pattern : only instance of the concrete user state
     */    
    protected static UserState singleton = null;
    
    /** Implementation of the singleton Design Pattern
     * @return the only instance of the concrete state
     */    
    public static UserState getInstance() {
        if (singleton == null) singleton = new Registered();
        return singleton;
    }
    
    /** Implementation of the singleton Design Pattern
     */    
    protected Registered() {}
    
    /** transition to the InMeeting state
     */    
    public void enter(MtgServer.Meeting meeting, MtgServer.User user_i)
    {
        user_i.setCurrentMeeting(meeting);
        user_i.setCurrentState(InMeeting.getInstance());
    }

}
