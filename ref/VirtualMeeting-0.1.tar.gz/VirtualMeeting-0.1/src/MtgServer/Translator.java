package MtgServer;

/** Translate messages (not implemented yet)
 */
public class Translator 
{

    /** Translates messages (not implemented yet)
     * @param targetLanguage target language
     * @param toTranslate_io message to translate
     */    
    public void translate(MtgServer.languages targetLanguage, MtgServer.Message toTranslate_io)
    {
       toTranslate_io.setText(toTranslate_io.getText() + " --translated in " + targetLanguage.toString() + " :-)");
       toTranslate_io.setLanguage(targetLanguage);
    }
}
