package MtgServer;


// objecteering-startJavadoc....................................N/7NB/CU7EYL1:D8
// objecteering-endJavadoc......................................E/7NB/CU7EYL1:D8
public class SoftTimer 
{
// objecteering-startJavadoc....................................N/EBC/0PELHP1:89
// objecteering-endJavadoc......................................E/EBC/0PELHP1:89
    protected MtgServer.Ringable ringables;
    public MtgServer.Ringable getRingables () {
        return this.ringables;
    }
    public int cardRingables () {
        if ( this.ringables == null ) return 0;
        else return 1;
    }

}
