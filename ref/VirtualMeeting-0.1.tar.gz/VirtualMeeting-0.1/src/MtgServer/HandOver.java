package MtgServer;


/** Syntax of the HANDOVER command
 * <CODE>
 * HANDOVER [user_name]
 * ex : HANDOVER spike
 *
 * Let the given user speak in the current meeting (must be performed by
 * the meeting moderator)
 * </CODE>
 */
public class HandOver 
    extends MtgServer.Command
{
    
    /** run a command
     * @param channel The channel of the user that executes the command
     * @param tokenizer_i the command arguments
     * @param server_i the virtual meeting server to perform command on
     */
    public void run(String channel, java.util.StringTokenizer tokenizer_i, MtgServer.Server server_i) 
    {
         User usr = null;
         // The user must be connected
         if ( (usr = checkUser(channel, server_i) ) == null ) return;
         
         // the user must be in a meeting
         Meeting mtg = usr.getCurrentMeeting();
         if (mtg == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("NotInMeeting"));
            return;
         }
         
         // security check
         if (mtg.getModerator() != usr) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("NotAllowed"));
            return;
         }
         
         // get the argument
        String name = null;
        // is there a user name ?
        if (!tokenizer_i.hasMoreTokens()) {
            this.sendIncorrectArgs(channel,server_i,"HANDOVER [user_name]");
            return;
        } 
        // get the name
        name = tokenizer_i.nextToken(" ");
        
        // get the user to hand over :
        User speaker = server_i.getUserByName(name);
        if (speaker == null) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidUser"));
            return;
        }
        
        // try to perform operation
        try {
            mtg.handOver(speaker, usr);
        }
        catch (Exception e) {
            sendError(channel, server_i, server_i.langByChannel(channel).get("InvalidOperation"));
        }
         
    }
    
}
