/*
 * NoMeetingTransitionException.java
 *
 * Created on 13 juillet 2002, 00:27
 */

package MtgServer;

/**
 *
 * @author  franck
 */
public class NoMeetingTransitionException extends VirtualMeetingException {
    
    /**
     * Creates a new instance of <code>NoMeetingTransitionException</code> without detail message.
     */
    public NoMeetingTransitionException() {
    }
    
    
    /**
     * Constructs an instance of <code>NoMeetingTransitionException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public NoMeetingTransitionException(String msg) {
        super(msg);
    }
}
